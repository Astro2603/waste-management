"""Generate a deterministic synthetic SQLite dataset for testing WasteWise."""

from __future__ import annotations

import argparse
import json
import math
import random
import sqlite3
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parent
SCHEMA_FILE = PROJECT_DIR / "schema.sql"

# Edit these settings to configure a run; command-line options override them.
OUTPUT_DATABASE = PROJECT_DIR / "wastewise.sqlite"
GENERATE_DAYS = 300
EVENTS_PER_DAY = 100
GENERATE_RECORDS: int | None = 50000  # Set to None to use EVENTS_PER_DAY instead.
# Set both dates to randomly choose GENERATE_DAYS dates within this range.
GENERATE_START_DATE: str | None = (
    datetime.now(timezone.utc).date() - timedelta(days=365)
).isoformat()
GENERATE_END_DATE: str | None = datetime.now(timezone.utc).date().isoformat()
RANDOM_SEED = 420
RUN_MODE = "append"  # Adds synthetic history to the website database without changing stock.

FOOD_CATALOG = {
    "Burger": [
        {"name": "Beef patty", "quantity": 0.20, "unit": "kg"},
        {"name": "Burger buns", "quantity": 1, "unit": "pcs"},
        {"name": "Lettuce", "quantity": 0.05, "unit": "kg"},
        {"name": "Tomato", "quantity": 0.07, "unit": "kg"},
        {"name": "Cheese", "quantity": 0.02, "unit": "kg"},
    ],
    "Chicken": [
        {"name": "Chicken", "quantity": 0.20, "unit": "kg"},
        {"name": "Fried chicken batter", "quantity": 0.06, "unit": "kg"},
        {"name": "Cooking oil", "quantity": 0.05, "unit": "L"},
        {"name": "Spices", "quantity": 0.01, "unit": "kg"},
    ],
    "Spaghetti": [
        {"name": "Pasta", "quantity": 0.20, "unit": "kg"},
        {"name": "Tomato sauce", "quantity": 0.10, "unit": "L"},
        {"name": "Ground beef", "quantity": 0.11, "unit": "kg"},
        {"name": "Cheese", "quantity": 0.02, "unit": "kg"},
    ],
}

INGREDIENT_UNITS = {
    ingredient["name"]: ingredient["unit"]
    for recipe in FOOD_CATALOG.values()
    for ingredient in recipe
}
DEFAULT_INGREDIENT_QUANTITIES = {
    name: 20 if unit == "pcs" else 10
    for name, unit in INGREDIENT_UNITS.items()
}


def iso_timestamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def random_timestamp(rng: random.Random, day: datetime, now: datetime) -> datetime:
    end_of_day = day + timedelta(days=1, seconds=-1)
    latest = min(end_of_day, now)
    seconds_available = max(0, int((latest - day).total_seconds()))
    return day + timedelta(seconds=rng.randint(0, seconds_available))


def parse_iso_date(value: str) -> date:
    try:
        parsed = date.fromisoformat(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("date must use YYYY-MM-DD format") from error
    if parsed.isoformat() != value:
        raise argparse.ArgumentTypeError("date must use YYYY-MM-DD format")
    return parsed


def build_dataset(
    rng: random.Random,
    days: int,
    events_per_day: int,
    now: datetime,
    record_count: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    events: list[dict[str, Any]] = []
    ingredient_totals = {name: 0.0 for name in INGREDIENT_UNITS}
    if (start_date is None) != (end_date is None):
        raise ValueError("Both start_date and end_date are required.")
    if start_date is not None and end_date is not None:
        if start_date > end_date:
            raise ValueError("start_date must be on or before end_date.")
        if end_date > now.date():
            raise ValueError("end_date cannot be in the future.")
        date_span = (end_date - start_date).days + 1
        if days > date_span:
            raise ValueError("days cannot exceed the number of dates in the selected range.")
        day_dates = [
            start_date + timedelta(days=offset)
            for offset in sorted(rng.sample(range(date_span), days))
        ]
    else:
        first_date = now.date() - timedelta(days=days - 1)
        day_dates = [first_date + timedelta(days=offset) for offset in range(days)]

    exact_event_types: list[str] = []
    if record_count is not None:
        disposal_count = record_count // 5
        exact_event_types = (
            ["food_use"] * (record_count - disposal_count)
            + ["disposal"] * disposal_count
        )
        guaranteed_food_names = list(FOOD_CATALOG)
        food_use_indexes = [
            index
            for index, event_type in enumerate(exact_event_types)
            if event_type == "food_use"
        ]
        for food_name, event_index in zip(guaranteed_food_names, food_use_indexes):
            exact_event_types[event_index] = f"food_use:{food_name}"
        rng.shuffle(exact_event_types)
    record_index = 0

    def create_food_use_event(
        day_start: datetime,
        guaranteed_food_name: str | None = None,
    ) -> dict[str, Any]:
        food_name = guaranteed_food_name or rng.choice(list(FOOD_CATALOG))
        portions = rng.randint(1, 8)
        used_at = random_timestamp(rng, day_start, now)
        recipe_snapshot = []
        for ingredient in FOOD_CATALOG[food_name]:
            quantity = round(ingredient["quantity"] * portions, 4)
            ingredient_totals[ingredient["name"]] += quantity
            recipe_snapshot.append({
                "name": ingredient["name"],
                "quantity": quantity,
                "unit": ingredient["unit"],
            })
        return {
            "type": "food_use",
            "at": used_at,
            "food": food_name,
            "portions": portions,
            "ingredients": recipe_snapshot,
        }

    def create_disposal_event(day_start: datetime) -> dict[str, Any]:
        disposed_at = random_timestamp(rng, day_start, now)
        if rng.random() < 0.65:
            ingredient_name = rng.choice(list(INGREDIENT_UNITS))
            quantity = round(rng.uniform(0.02, 0.50), 2)
            ingredient_totals[ingredient_name] += quantity
            return {
                "type": "ingredient_disposal",
                "at": disposed_at,
                "name": ingredient_name,
                "quantity": quantity,
                "unit": INGREDIENT_UNITS[ingredient_name],
            }
        return {
            "type": "food_disposal",
            "at": disposed_at,
            "name": rng.choice(list(FOOD_CATALOG)),
            "quantity": rng.randint(1, 6),
            "unit": "portions",
        }

    for day_index, day_date in enumerate(day_dates):
        day_start = datetime.combine(day_date, time.min, tzinfo=timezone.utc)
        if record_count is not None:
            event_count, extra_events = divmod(record_count, days)
            event_count += int(day_index < extra_events)
            for _ in range(event_count):
                event_type = exact_event_types[record_index]
                if event_type.startswith("food_use"):
                    guaranteed_food_name = (
                        event_type.split(":", 1)[1]
                        if ":" in event_type
                        else None
                    )
                    events.append(
                        create_food_use_event(day_start, guaranteed_food_name)
                    )
                else:
                    events.append(create_disposal_event(day_start))
                record_index += 1
        else:
            if events_per_day:
                minimum_events = max(1, events_per_day - 3)
                event_count = rng.randint(minimum_events, events_per_day + 3)
            else:
                event_count = 0
            events.extend(create_food_use_event(day_start) for _ in range(event_count))
            events.extend(
                create_disposal_event(day_start)
                for _ in range(rng.randint(0, 3))
            )

    events.sort(key=lambda event: event["at"])
    opening_stock = {}
    for name, required in ingredient_totals.items():
        opening_quantity = required * 1.20 + 2
        if INGREDIENT_UNITS[name] == "pcs":
            opening_stock[name] = float(math.ceil(opening_quantity))
        else:
            opening_stock[name] = round(opening_quantity, 2)
    return events, [{"name": name, "quantity": quantity} for name, quantity in opening_stock.items()]


def reset_schema(connection: sqlite3.Connection) -> None:
    connection.executescript("""
        DROP TABLE IF EXISTS food_use_records;
        DROP TABLE IF EXISTS disposal_records;
        DROP TABLE IF EXISTS food_recipe_items;
        DROP TABLE IF EXISTS food_items;
        DROP TABLE IF EXISTS ingredients;
    """)
    connection.executescript(SCHEMA_FILE.read_text(encoding="utf-8"))


def populate_database(
    connection: sqlite3.Connection,
    rng: random.Random,
    days: int,
    events_per_day: int,
    record_count: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
) -> tuple[int, int, int]:
    now = datetime.now(timezone.utc)
    events, opening_stock = build_dataset(
        rng,
        days,
        events_per_day,
        now,
        record_count,
        start_date,
        end_date,
    )
    current_stock = {item["name"]: item["quantity"] for item in opening_stock}

    for ingredient in opening_stock:
        expiry_offset = rng.choice([None, -5, -2, 1, 3, 7, 14, 30])
        expires_at = None
        if expiry_offset is not None:
            expires_at = iso_timestamp(now + timedelta(days=expiry_offset))
        connection.execute(
            """INSERT INTO ingredients (name, quantity, expires_at, unit)
               VALUES (?, ?, ?, ?)""",
            (
                ingredient["name"],
                ingredient["quantity"],
                expires_at,
                INGREDIENT_UNITS[ingredient["name"]],
            ),
        )

    food_ids = {}
    for food_name, recipe in FOOD_CATALOG.items():
        cursor = connection.execute("INSERT INTO food_items (name) VALUES (?)", (food_name,))
        food_id = int(cursor.lastrowid)
        food_ids[food_name] = food_id
        connection.executemany(
            """INSERT INTO food_recipe_items
               (food_id, ingredient_name, quantity, unit) VALUES (?, ?, ?, ?)""",
            [
                (food_id, item["name"], item["quantity"], item["unit"])
                for item in recipe
            ],
        )

    food_use_count = 0
    disposal_count = 0
    for event in events:
        timestamp = iso_timestamp(event["at"])
        if event["type"] == "food_use":
            for ingredient in event["ingredients"]:
                current_stock[ingredient["name"]] -= ingredient["quantity"]
            connection.execute(
                """INSERT INTO food_use_records
                   (food_name, portions, used_at, ingredients_used)
                   VALUES (?, ?, ?, ?)""",
                (
                    event["food"],
                    event["portions"],
                    timestamp,
                    json.dumps(event["ingredients"], separators=(",", ":")),
                ),
            )
            food_use_count += 1
        elif event["type"] == "ingredient_disposal":
            name = event["name"]
            current_stock[name] -= event["quantity"]
            connection.execute(
                "UPDATE ingredients SET quantity = ? WHERE name = ?",
                (round(current_stock[name], 4), name),
            )
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES ('ingredient', ?, ?, ?, ?)""",
                (name, event["quantity"], event["unit"], timestamp),
            )
            disposal_count += 1
        else:
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES ('food', ?, ?, ?, ?)""",
                (event["name"], event["quantity"], event["unit"], timestamp),
            )
            disposal_count += 1

    return len(opening_stock), len(food_ids), food_use_count + disposal_count


def append_history(
    connection: sqlite3.Connection,
    rng: random.Random,
    days: int,
    events_per_day: int,
    record_count: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
) -> int:
    required_tables = {
        "ingredients",
        "food_items",
        "food_use_records",
        "disposal_records",
    }
    existing_tables = {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }
    missing_tables = required_tables - existing_tables
    if missing_tables:
        raise ValueError(
            "The target is missing WasteWise tables: " + ", ".join(sorted(missing_tables))
        )

    food_names = {
        row[0].strip().lower()
        for row in connection.execute("SELECT name FROM food_items")
    }
    missing_foods = set(FOOD_CATALOG) - {name.title() for name in food_names}
    if missing_foods:
        raise ValueError(
            "Add the default food catalog before appending history; missing: "
            + ", ".join(sorted(missing_foods))
        )

    events, _ = build_dataset(
        rng,
        days,
        events_per_day,
        datetime.now(timezone.utc),
        record_count,
        start_date,
        end_date,
    )
    for event in events:
        timestamp = iso_timestamp(event["at"])
        if event["type"] == "food_use":
            connection.execute(
                """INSERT INTO food_use_records
                   (food_name, portions, used_at, ingredients_used)
                   VALUES (?, ?, ?, ?)""",
                (
                    event["food"],
                    event["portions"],
                    timestamp,
                    json.dumps(event["ingredients"], separators=(",", ":")),
                ),
            )
        else:
            item_type = "ingredient" if event["type"] == "ingredient_disposal" else "food"
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    item_type,
                    event["name"],
                    event["quantity"],
                    event["unit"],
                    timestamp,
                ),
            )
    return len(events)


def add_missing_ingredients(connection: sqlite3.Connection) -> int:
    existing_names = {
        row[0].strip().lower()
        for row in connection.execute("SELECT name FROM ingredients")
    }
    new_ingredients = [
        (name, DEFAULT_INGREDIENT_QUANTITIES[name], INGREDIENT_UNITS[name])
        for name in INGREDIENT_UNITS
        if name.strip().lower() not in existing_names
    ]
    connection.executemany(
        """INSERT INTO ingredients (name, quantity, expires_at, unit)
           VALUES (?, ?, NULL, ?)""",
        new_ingredients,
    )
    return len(new_ingredients)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create deterministic synthetic data in a separate WasteWise SQLite database."
    )
    parser.add_argument("--db", type=Path, default=OUTPUT_DATABASE,
                        help=f"output database path (default: {OUTPUT_DATABASE.name})")
    parser.add_argument("--days", type=int, default=GENERATE_DAYS,
                        help=f"number of days to generate (1-3650; default: {GENERATE_DAYS}); random within a date range")
    parser.add_argument("--events-per-day", type=int, default=EVENTS_PER_DAY,
                        help=f"approximate food-use records per day (0-100; default: {EVENTS_PER_DAY})")
    parser.add_argument("--records", type=int, default=GENERATE_RECORDS,
                        help="exact number of food-use and disposal records to generate; overrides --events-per-day")
    parser.add_argument("--start-date", type=parse_iso_date, default=GENERATE_START_DATE,
                        help='start of date range (YYYY-MM-DD; requires --end-date)')
    parser.add_argument("--end-date", type=parse_iso_date, default=GENERATE_END_DATE,
                        help='end of date range (YYYY-MM-DD; requires --start-date)')
    parser.add_argument("--seed", type=int, default=RANDOM_SEED,
                        help=f"random seed for repeatable data (default: {RANDOM_SEED})")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--append", action="store_true", default=None,
                      help="append synthetic history to an existing database without changing stock")
    mode.add_argument("--reset", action="store_true", default=None,
                        help="replace WasteWise tables in the target database if it exists")
    args = parser.parse_args()
    if RUN_MODE not in {"create", "reset", "append"}:
        parser.error('RUN_MODE must be "create", "reset", or "append"')
    if args.append is None and args.reset is None:
        args.append = RUN_MODE == "append"
        args.reset = RUN_MODE == "reset"
    else:
        args.append = bool(args.append)
        args.reset = bool(args.reset)
    if not 1 <= args.days <= 3650:
        parser.error("--days must be between 1 and 3650")
    if not 0 <= args.events_per_day <= 100:
        parser.error("--events-per-day must be between 0 and 100")
    if args.records is not None and args.records < 0:
        parser.error("--records must be zero or greater")
    if (args.start_date is None) != (args.end_date is None):
        parser.error("--start-date and --end-date must be used together")
    if args.start_date is not None and args.end_date is not None:
        if args.start_date > args.end_date:
            parser.error("--start-date must be on or before --end-date")
        if args.end_date > datetime.now(timezone.utc).date():
            parser.error("--end-date cannot be in the future")
        date_span = (args.end_date - args.start_date).days + 1
        if args.days > date_span:
            parser.error("--days cannot exceed the number of dates in the selected range")
    if args.append and not args.db.is_file():
        parser.error(f"{args.db} does not exist; use --reset to create a new database")
    if args.db.exists() and args.db.stat().st_size > 0 and not (args.append or args.reset):
        parser.error(f"{args.db} already exists; pass --append to preserve data or --reset to replace it")
    return args


def main() -> None:
    args = parse_args()
    args.db.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    connection = sqlite3.connect(args.db)
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        with connection:
            if args.append:
                event_count = append_history(
                    connection,
                    rng,
                    args.days,
                    args.events_per_day,
                    args.records,
                    args.start_date,
                    args.end_date,
                )
                added_ingredient_count = add_missing_ingredients(connection)
            else:
                reset_schema(connection)
                populate_database(
                    connection,
                    rng,
                    args.days,
                    args.events_per_day,
                    args.records,
                    args.start_date,
                    args.end_date,
                )
        totals = {
            table: connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in (
                "ingredients",
                "food_items",
                "food_recipe_items",
                "food_use_records",
                "disposal_records",
            )
        }
    finally:
        connection.close()

    print(f"Synthetic dataset created: {args.db.resolve()}")
    print(f"Seed: {args.seed}; days: {args.days}")
    if args.start_date is not None and args.end_date is not None:
        print(
            f"Date range: {args.start_date.isoformat()} through "
            f"{args.end_date.isoformat()}; random days selected: {args.days}"
        )
    if args.records is None:
        print(f"Events per day: approximately {args.events_per_day}")
    else:
        print(f"Requested records: {args.records}")
    if args.append:
        print(
            f"Appended history events: {event_count}; "
            f"added missing ingredients: {added_ingredient_count}; "
            "existing inventory quantities were not changed."
        )
    print("Rows: " + ", ".join(f"{table}={count}" for table, count in totals.items()))


if __name__ == "__main__":
    main()