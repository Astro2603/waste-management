const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const sqlite3 = require('sqlite3').verbose();

const dbPath = path.resolve(__dirname, process.env.DB_FILE || 'wastewise.sqlite');
const sqlite = new sqlite3.Database(dbPath);
let operationQueue = Promise.resolve();

const defaultIngredients = [
  { name: 'Chicken', quantity: 10 },
  { name: 'Fried chicken batter', quantity: 10 },
  { name: 'Cooking oil', quantity: 10 },
  { name: 'Spices', quantity: 10 },
  { name: 'Beef patty', quantity: 10 },
  { name: 'Burger buns', quantity: 20 },
  { name: 'Lettuce', quantity: 10 },
  { name: 'Tomato', quantity: 10 },
  { name: 'Cheese', quantity: 10 },
  { name: 'Pasta', quantity: 10 },
  { name: 'Tomato sauce', quantity: 10 },
  { name: 'Ground beef', quantity: 10 },
];

const defaultRecipeCatalog = [
  {
    name: 'Burger',
    recipe: [
      { name: 'Beef patty', quantity: 0.20, unit: 'kg' },
      { name: 'Burger buns', quantity: 1, unit: 'pcs' },
      { name: 'Lettuce', quantity: 0.05, unit: 'kg' },
      { name: 'Tomato', quantity: 0.07, unit: 'kg' },
      { name: 'Cheese', quantity: 0.02, unit: 'kg' },
    ],
  },
  {
    name: 'Chicken',
    recipe: [
      { name: 'Chicken', quantity: 0.20, unit: 'kg' },
      { name: 'Fried chicken batter', quantity: 0.06, unit: 'kg' },
      { name: 'Cooking oil', quantity: 0.05, unit: 'L' },
      { name: 'Spices', quantity: 0.01, unit: 'kg' },
    ],
  },
  {
    name: 'Spaghetti',
    recipe: [
      { name: 'Pasta', quantity: 0.20, unit: 'kg' },
      { name: 'Tomato sauce', quantity: 0.10, unit: 'L' },
      { name: 'Ground beef', quantity: 0.11, unit: 'kg' },
      { name: 'Cheese', quantity: 0.02, unit: 'kg' },
    ],
  },
];

function acquireLock() {
  let unlock;
  const gate = new Promise((resolve) => { unlock = resolve; });
  const previous = operationQueue;
  operationQueue = previous.then(() => gate);
  return previous.then(() => unlock);
}

function execute(sql, values = []) {
  return new Promise((resolve, reject) => {
    const isRead = /^\s*(SELECT|PRAGMA|WITH)\b/i.test(sql);
    const callback = function (error, rows) {
      if (error) {
        if (error.message.includes('UNIQUE constraint failed')) error.code = 'ER_DUP_ENTRY';
        reject(error);
      } else if (isRead) {
        resolve([rows, undefined]);
      } else {
        resolve([{ insertId: this.lastID, affectedRows: this.changes }, undefined]);
      }
    };

    if (isRead) sqlite.all(sql, values, callback);
    else sqlite.run(sql, values, callback);
  });
}

async function query(sql, values = []) {
  const unlock = await acquireLock();
  try {
    return await execute(sql, values);
  } finally {
    unlock();
  }
}

async function getConnection() {
  const unlock = await acquireLock();
  let released = false;

  return {
    query: execute,
    beginTransaction: () => execute('BEGIN IMMEDIATE'),
    commit: () => execute('COMMIT'),
    rollback: () => execute('ROLLBACK'),
    release() {
      if (!released) {
        released = true;
        unlock();
      }
    }
  };
}

async function seedDefaultInventory() {
  const [rows] = await query('SELECT name FROM ingredients');
  const existingNames = new Set((rows || []).map((row) => String(row.name).trim().toLowerCase()));

  for (const ingredient of defaultIngredients) {
    if (!existingNames.has(ingredient.name.trim().toLowerCase())) {
      await query(
        'INSERT INTO ingredients (name, quantity, expires_at) VALUES (?, ?, NULL)',
        [ingredient.name, ingredient.quantity]
      );
      existingNames.add(ingredient.name.trim().toLowerCase());
    }
  }
}

async function seedDefaultRecipes() {
  const [existingFoods] = await query('SELECT name FROM food_items');
  const existingFoodNames = new Set((existingFoods || []).map((row) => String(row.name).trim().toLowerCase()));

  for (const food of defaultRecipeCatalog) {
    const foodKey = food.name.trim().toLowerCase();
    if (!existingFoodNames.has(foodKey)) {
      const [result] = await query('INSERT INTO food_items (name) VALUES (?)', [food.name]);
      const foodId = Number(result.insertId);
      for (const item of food.recipe) {
        await query(
          'INSERT INTO food_recipe_items (food_id, ingredient_name, quantity, unit) VALUES (?, ?, ?, ?)',
          [foodId, item.name, Number(item.quantity), item.unit]
        );
      }
      existingFoodNames.add(foodKey);
      continue;
    }

    const [foodRow] = await query('SELECT id FROM food_items WHERE lower(name) = ?', [foodKey]);
    const foodId = Number(foodRow[0]?.id || 0);
    if (!foodId) continue;

    const [existingRecipeRows] = await query(
      'SELECT ingredient_name FROM food_recipe_items WHERE food_id = ?',
      [foodId]
    );
    const existingRecipeNames = new Set((existingRecipeRows || []).map((row) => String(row.ingredient_name).trim().toLowerCase()));

    for (const item of food.recipe) {
      const itemKey = item.name.trim().toLowerCase();
      if (!existingRecipeNames.has(itemKey)) {
        await query(
          'INSERT INTO food_recipe_items (food_id, ingredient_name, quantity, unit) VALUES (?, ?, ?, ?)',
          [foodId, item.name, Number(item.quantity), item.unit]
        );
        existingRecipeNames.add(itemKey);
      }
    }
  }
}

async function initialize() {
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL COLLATE NOCASE UNIQUE,
      password_salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS auth_sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      expires_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  await query('CREATE INDEX IF NOT EXISTS idx_auth_sessions_expires_at ON auth_sessions(expires_at)');
  await query('DELETE FROM auth_sessions WHERE expires_at <= ?', [Date.now()]);

  await query(`
    CREATE TABLE IF NOT EXISTS ingredients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      quantity REAL NOT NULL DEFAULT 0,
      expires_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  const [columns] = await query('PRAGMA table_info(ingredients)');
  if (!columns.some((column) => column.name === 'expires_at')) {
    await query('ALTER TABLE ingredients ADD COLUMN expires_at TEXT');
  }

  await query(`
    CREATE TABLE IF NOT EXISTS disposal_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      item_type TEXT NOT NULL CHECK (item_type IN ('ingredient', 'food')),
      item_name TEXT NOT NULL,
      quantity REAL NOT NULL,
      unit TEXT NOT NULL,
      disposed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);
  await query('CREATE INDEX IF NOT EXISTS idx_disposal_records_disposed_at ON disposal_records(disposed_at)');

  await query(`
    CREATE TABLE IF NOT EXISTS food_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS food_recipe_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      food_id INTEGER NOT NULL,
      ingredient_name TEXT NOT NULL,
      quantity REAL NOT NULL,
      unit TEXT NOT NULL,
      FOREIGN KEY (food_id) REFERENCES food_items(id) ON DELETE CASCADE
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS food_use_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      food_name TEXT NOT NULL,
      portions INTEGER NOT NULL,
      used_at TEXT NOT NULL,
      ingredients_used TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await seedDefaultInventory();
  await seedDefaultRecipes();
}

module.exports = { query, getConnection, initialize, dbPath };
