const express = require('express');
const cors = require('cors');
const {
  createHash,
  randomBytes,
  scrypt: scryptCallback,
  timingSafeEqual,
} = require('crypto');
const { promisify } = require('util');
const path = require('path');
const database = require('./db');

const app = express();
const port = Number(process.env.PORT || 3001);
const scrypt = promisify(scryptCallback);
const SESSION_COOKIE = 'wastewise_session';
const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;
const FOOD_USE_SHELF_LIFE_HOURS = 3;
const FOOD_USE_EXPIRING_WINDOW_MINUTES = 30;

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10kb' }));

function readSessionToken(req) {
  const cookieHeader = req.headers.cookie || '';
  const sessionCookie = cookieHeader
    .split(';')
    .map((cookie) => cookie.trim())
    .find((cookie) => cookie.startsWith(`${SESSION_COOKIE}=`));
  const token = sessionCookie?.slice(SESSION_COOKIE.length + 1);
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}

function hashSessionToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

function setSessionCookie(res, req, token) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_LIFETIME_MS / 1000}${secure}`
  );
}

function clearSessionCookie(res, req) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`
  );
}

async function findSessionUser(req) {
  const token = readSessionToken(req);
  if (!token) return null;

  const [users] = await database.query(
    `SELECT users.id, users.name, users.email
     FROM auth_sessions
     JOIN users ON users.id = auth_sessions.user_id
     WHERE auth_sessions.token_hash = ? AND auth_sessions.expires_at > ?`,
    [hashSessionToken(token), Date.now()]
  );
  return users[0] || null;
}

async function createSession(req, res, userId) {
  const token = randomBytes(32).toString('hex');
  await database.query(
    'INSERT INTO auth_sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)',
    [hashSessionToken(token), userId, Date.now() + SESSION_LIFETIME_MS]
  );
  setSessionCookie(res, req, token);
}

function normalizeEmail(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function validEmail(email) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function normalizeStockUnit(value) {
  if (typeof value !== 'string') return null;
  const unit = value.trim().toLowerCase();
  if (unit === 'kg') return 'kg';
  if (unit === 'pcs' || unit === 'pieces') return 'pcs';
  if (unit === 'packs') return 'packs';
  if (unit === 'l' || unit === 'liters' || unit === 'litres') return 'L';
  return null;
}

function getStockBaseUnit(unit, packUnit) {
  return unit === 'packs' ? packUnit : unit;
}

function getBatchQuantityInUnit(batch, unit) {
  if (batch.unit === unit) return Number(batch.quantity);
  if (batch.unit === 'packs' && batch.pack_unit === unit) {
    return Number(batch.quantity) * Number(batch.pack_size);
  }
  return 0;
}

function getBatchDeductionInStockUnit(batch, quantity, unit) {
  if (batch.unit === 'packs' && batch.pack_unit === unit) {
    return quantity / Number(batch.pack_size);
  }
  return quantity;
}

function defaultStockUnit(name) {
  const knownUnits = {
    'burger buns': 'pcs',
    'cooking oil': 'L',
    'tomato sauce': 'L',
  };
  return knownUnits[name.trim().toLowerCase()] || 'kg';
}

async function hashPassword(password, salt) {
  return (await scrypt(password, salt, 64)).toString('hex');
}

app.post('/api/auth/signup', async (req, res) => {
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const email = normalizeEmail(body.email);
  const password = typeof body.password === 'string' ? body.password : '';
  if (!name || name.length > 80 || !validEmail(email) || password.length < 8 || password.length > 128) {
    return res.status(400).json({
      error: 'Enter a name, valid email address, and password between 8 and 128 characters.',
    });
  }

  try {
    const salt = randomBytes(16).toString('hex');
    const passwordHash = await hashPassword(password, salt);
    const [result] = await database.query(
      'INSERT INTO users (name, email, password_salt, password_hash) VALUES (?, ?, ?, ?)',
      [name, email, salt, passwordHash]
    );
    return res.status(201).json({ success: true });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'An account with that email already exists.' });
    }
    console.error(error);
    return res.status(500).json({ error: 'Could not create your account.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const body = req.body || {};
  const email = normalizeEmail(body.email);
  const password = typeof body.password === 'string' ? body.password : '';
  if (!validEmail(email) || !password || password.length > 128) {
    return res.status(400).json({ error: 'Enter a valid email address and password.' });
  }

  try {
    const [users] = await database.query(
      'SELECT id, name, email, password_salt, password_hash FROM users WHERE email = ?',
      [email]
    );
    const user = users[0];
    if (!user) return res.status(401).json({ error: 'Email or password is incorrect.' });

    const passwordHash = await hashPassword(password, user.password_salt);
    const expectedHash = Buffer.from(user.password_hash, 'hex');
    const actualHash = Buffer.from(passwordHash, 'hex');
    if (expectedHash.length !== actualHash.length || !timingSafeEqual(expectedHash, actualHash)) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }

    await createSession(req, res, user.id);
    return res.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not sign in.' });
  }
});

app.get('/api/auth/me', async (req, res) => {
  try {
    const user = await findSessionUser(req);
    if (!user) return res.status(401).json({ error: 'Please sign in to continue.' });
    return res.json({ user });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not verify your session.' });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try {
    const token = readSessionToken(req);
    if (token) {
      await database.query('DELETE FROM auth_sessions WHERE token_hash = ?', [hashSessionToken(token)]);
    }
    clearSessionCookie(res, req);
    return res.json({ success: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not sign out.' });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    await database.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (error) {
    console.error(error);
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

app.use('/api', async (req, res, next) => {
  try {
    const user = await findSessionUser(req);
    if (!user) return res.status(401).json({ error: 'Please sign in to continue.' });
    req.user = user;
    return next();
  } catch (error) {
    console.error(error);
    return res.status(503).json({ error: 'Could not verify your session.' });
  }
});

app.get('/api/ingredients', async (req, res) => {
  try {
    const [ingredients] = await database.query(
      'SELECT * FROM ingredients ORDER BY name, expires_at IS NULL, expires_at, id'
    );

    res.json(ingredients);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

app.post('/api/ingredients', async (req, res) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const quantity = Number(req.body.quantity);
    const expiresAt = parseExpiryDate(req.body.expiresAt);
    const unit = req.body.unit === undefined ? defaultStockUnit(name) : normalizeStockUnit(req.body.unit);
    const packSize = unit === 'packs' ? Number(req.body.packSize) : null;
    const packUnit = unit === 'packs' ? normalizeStockUnit(req.body.packUnit) : null;
    if (!name || name.length > 100 || !Number.isFinite(quantity) || quantity < 0 || expiresAt === false
      || !unit || (unit === 'packs' && (!Number.isFinite(packSize) || packSize <= 0 || !packUnit || packUnit === 'packs'))) {
      return res.status(400).json({ error: 'Name, a non-negative quantity, and a valid expiry time are required.' });
    }

    const [existingBatches] = await database.query(
      'SELECT unit, pack_unit FROM ingredients WHERE lower(name) = ?',
      [name.toLowerCase()]
    );
    if (existingBatches.some((batch) => getStockBaseUnit(batch.unit, batch.pack_unit) !== getStockBaseUnit(unit, packUnit))) {
      return res.status(409).json({ error: 'Batches of the same ingredient must use the same base unit.' });
    }

    const [result] = await database.query(
      `INSERT INTO ingredients (name, quantity, expires_at, unit, pack_size, pack_unit)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [name, quantity, expiresAt, unit, packSize, packUnit]
    );

    return res.status(201).json({
      id: result.insertId,
      name,
      unit,
      quantity: Number(quantity),
      expires_at: expiresAt,
      minimum_quantity: 0,
      pack_size: packSize,
      pack_unit: packUnit,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not add ingredient.' });
  }
});

app.post('/api/ingredients/consume', async (req, res) => {
  const items = req.body.items;
  if (!Array.isArray(items) || items.length === 0 || items.some((item) => (
    !item || typeof item !== 'object'
    || !Number.isInteger(Number(item.id)) || Number(item.id) < 1
    || !Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0
  )) || new Set(items.map((item) => Number(item.id))).size !== items.length) {
    return res.status(400).json({ error: 'Valid ingredient IDs and positive quantities are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const ids = items.map((item) => Number(item.id));
    const placeholders = ids.map(() => '?').join(', ');
    const [stocks] = await connection.query(
      `SELECT id, quantity FROM ingredients WHERE id IN (${placeholders})`,
      ids
    );
    if (stocks.length !== items.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'One or more ingredients were not found.' });
    }

    const stockById = new Map(stocks.map((stock) => [Number(stock.id), Number(stock.quantity)]));
    const insufficientItem = items.find((item) => (
      stockById.get(Number(item.id)) + 0.000001 < Number(item.quantity)
    ));
    if (insufficientItem) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: `Not enough stock for ingredient ${insufficientItem.id}.` });
    }

    for (const item of items) {
      await connection.query(
        'UPDATE ingredients SET quantity = quantity - ? WHERE id = ?',
        [Number(item.quantity), Number(item.id)]
      );
    }

    const [updatedIngredients] = await connection.query(
      `SELECT id, quantity FROM ingredients WHERE id IN (${placeholders})`,
      ids
    );
    await connection.commit();
    transactionStarted = false;
    return res.json({
      ingredients: updatedIngredients.map((ingredient) => ({
        id: Number(ingredient.id),
        quantity: Number(ingredient.quantity),
      })),
    });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not deduct ingredient stock.' });
  } finally {
    if (connection) connection.release();
  }
});

app.put('/api/ingredients/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : null;
    const quantity = Number(req.body.quantity);
    const hasExpiry = Object.prototype.hasOwnProperty.call(req.body, 'expiresAt');
    const expiresAt = hasExpiry ? parseExpiryDate(req.body.expiresAt) : undefined;
    const hasUnit = Object.prototype.hasOwnProperty.call(req.body, 'unit');
    const unit = hasUnit ? normalizeStockUnit(req.body.unit) : undefined;
    const packSize = unit === 'packs' ? Number(req.body.packSize) : null;
    const packUnit = unit === 'packs' ? normalizeStockUnit(req.body.packUnit) : null;
    if (!Number.isInteger(id) || id < 1 || !Number.isFinite(quantity) || quantity < 0 || expiresAt === false
      || (name !== null && (!name || name.length > 100))
      || (hasUnit && (!unit || (unit === 'packs' && (!Number.isFinite(packSize) || packSize <= 0 || !packUnit || packUnit === 'packs'))))) {
      return res.status(400).json({ error: 'A valid ingredient ID, name, non-negative quantity, and expiry time are required.' });
    }

    const [currentRows] = await database.query('SELECT * FROM ingredients WHERE id = ?', [id]);
    if (currentRows.length === 0) return res.status(404).json({ error: 'Ingredient not found.' });
    const updatedName = name === null ? currentRows[0].name : name;
    const updatedUnit = hasUnit ? unit : currentRows[0].unit;
    const updatedPackUnit = hasUnit ? packUnit : currentRows[0].pack_unit;
    const [otherBatches] = await database.query(
      'SELECT unit, pack_unit FROM ingredients WHERE lower(name) = ? AND id != ?',
      [updatedName.toLowerCase(), id]
    );
    if (otherBatches.some((batch) => getStockBaseUnit(batch.unit, batch.pack_unit) !== getStockBaseUnit(updatedUnit, updatedPackUnit))) {
      return res.status(409).json({ error: 'Batches of the same ingredient must use the same base unit.' });
    }

    const fields = name === null ? ['quantity = ?'] : ['name = ?', 'quantity = ?'];
    const values = name === null ? [quantity] : [name, quantity];
    if (hasExpiry) {
      fields.push('expires_at = ?');
      values.push(expiresAt);
    }
    if (hasUnit) {
      fields.push('unit = ?', 'pack_size = ?', 'pack_unit = ?');
      values.push(unit, packSize, packUnit);
    }
    await database.query(`UPDATE ingredients SET ${fields.join(', ')} WHERE id = ?`, [...values, id]);

    const [rows] = await database.query('SELECT * FROM ingredients WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Ingredient not found.' });
    return res.json(rows[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not update ingredient.' });
  }
});

app.delete('/api/ingredients/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) {
      return res.status(400).json({ error: 'A valid ingredient ID is required.' });
    }

    const [result] = await database.query('DELETE FROM ingredients WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Ingredient not found.' });
    return res.json({ id });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not remove ingredient.' });
  }
});

app.delete('/api/ingredients', async (req, res) => {
  try {
    const [result] = await database.query('DELETE FROM ingredients');
    return res.json({ deleted: result.affectedRows });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not clear ingredient stock.' });
  }
});

function parseExpiryDate(value) {
  if (value === undefined || value === null || value === '') return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? false : date.toISOString();
}

app.post('/api/ingredients/:id/dispose', async (req, res) => {
  const connection = await database.getConnection();
  let transactionStarted = false;
  try {
    const id = Number(req.params.id);
    const quantity = Number(req.body.quantity);
    const unit = typeof req.body.unit === 'string' ? req.body.unit.trim() : 'kg';
    if (!Number.isInteger(id) || id < 1 || !Number.isFinite(quantity) || quantity <= 0 || !unit || unit.length > 20) {
      return res.status(400).json({ error: 'A valid ingredient ID and positive disposal quantity are required.' });
    }

    await connection.beginTransaction();
    transactionStarted = true;
    const [ingredients] = await connection.query(
      'SELECT id, name, quantity FROM ingredients WHERE id = ?',
      [id]
    );
    if (ingredients.length === 0) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'Ingredient not found.' });
    }
    if (Number(ingredients[0].quantity) + 0.000001 < quantity) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: 'Stock changed before disposal. Refresh inventory and try again.' });
    }

    await connection.query('UPDATE ingredients SET quantity = quantity - ? WHERE id = ?', [quantity, id]);
    await connection.query(
      'INSERT INTO disposal_records (item_type, item_name, quantity, unit) VALUES (?, ?, ?, ?)',
      ['ingredient', ingredients[0].name, quantity, unit]
    );

    const [rows] = await connection.query('SELECT id, quantity FROM ingredients WHERE id = ?', [id]);
    await connection.commit();
    transactionStarted = false;
    return res.json({ id, quantity: Number(rows[0].quantity) });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not dispose ingredient stock.' });
  } finally {
    connection.release();
  }
});

app.post('/api/disposals', async (req, res) => {
  const items = req.body.items;
  if (!Array.isArray(items) || items.length === 0 || items.some((item) => (
    !item || item.itemType !== 'food'
    || typeof item.itemName !== 'string' || !item.itemName.trim() || item.itemName.trim().length > 100
    || !Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0
    || typeof item.unit !== 'string' || !item.unit.trim() || item.unit.trim().length > 20
  ))) {
    return res.status(400).json({ error: 'Valid food names, positive quantities, and units are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;
    for (const item of items) {
      await connection.query(
        'INSERT INTO disposal_records (item_type, item_name, quantity, unit) VALUES (?, ?, ?, ?)',
        ['food', item.itemName.trim(), Number(item.quantity), item.unit.trim()]
      );
    }
    await connection.commit();
    transactionStarted = false;
    return res.status(201).json({ recorded: items.length });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not save disposal records.' });
  } finally {
    if (connection) connection.release();
  }
});

app.get('/api/disposals', async (req, res) => {
  const { startDate, endDate } = req.query;
  const hasDateRange = startDate !== undefined || endDate !== undefined;
  const isDateKey = (value) => (
    typeof value === 'string'
    && /^\d{4}-\d{2}-\d{2}$/.test(value)
    && !Number.isNaN(Date.parse(`${value}T00:00:00Z`))
    && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value
  );
  if (hasDateRange && (!isDateKey(startDate) || !isDateKey(endDate) || startDate > endDate)) {
    return res.status(400).json({ error: 'A valid start and end date are required.' });
  }

  try {
    const [records] = hasDateRange
      ? await database.query(
        `SELECT id, item_type, item_name, quantity, unit, disposed_at
         FROM disposal_records
         WHERE date(disposed_at) BETWEEN date(?) AND date(?)
         ORDER BY disposed_at DESC`,
        [startDate, endDate]
      )
      : await database.query(
        'SELECT id, item_type, item_name, quantity, unit, disposed_at FROM disposal_records ORDER BY disposed_at DESC LIMIT 100'
      );
    return res.json(records);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load disposal records.' });
  }
});

app.delete('/api/disposals', async (req, res) => {
  try {
    const [result] = await database.query('DELETE FROM disposal_records');
    return res.json({ deleted: result.affectedRows });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not clear disposal records.' });
  }
});

app.get('/api/food-items', async (req, res) => {
  try {
    const [foods] = await database.query(
      'SELECT id, name, waste_weight_kg_per_portion FROM food_items ORDER BY name'
    );
    const [recipeRows] = await database.query(
      'SELECT food_id, ingredient_name, quantity, unit FROM food_recipe_items ORDER BY food_id, ingredient_name'
    );

    const recipeMap = new Map();
    recipeRows.forEach((row) => {
      if (!recipeMap.has(Number(row.food_id))) {
        recipeMap.set(Number(row.food_id), []);
      }
      recipeMap.get(Number(row.food_id)).push({
        name: row.ingredient_name,
        quantity: Number(row.quantity),
        unit: row.unit,
      });
    });

    return res.json(foods.map((food) => ({
      id: Number(food.id),
      name: food.name,
      wasteWeightKgPerPortion: food.waste_weight_kg_per_portion === null
        ? null
        : Number(food.waste_weight_kg_per_portion),
      recipe: recipeMap.get(Number(food.id)) || [],
    })));
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load food items.' });
  }
});

app.put('/api/food-items/:id/waste-weight', async (req, res) => {
  const id = Number(req.params.id);
  const wasteWeightKgPerPortion = Number(req.body?.wasteWeightKgPerPortion);
  if (!Number.isSafeInteger(id) || id < 1
    || !Number.isFinite(wasteWeightKgPerPortion)
    || wasteWeightKgPerPortion <= 0 || wasteWeightKgPerPortion > 100) {
    return res.status(400).json({ error: 'Enter a food ID and a weight per portion greater than 0 and no more than 100 kg.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;
    const [foods] = await connection.query('SELECT id, name FROM food_items WHERE id = ?', [id]);
    if (!foods.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'Food item not found.' });
    }

    await connection.query(
      'UPDATE food_items SET waste_weight_kg_per_portion = ? WHERE id = ?',
      [wasteWeightKgPerPortion, id]
    );
    const [converted] = await connection.query(
      `UPDATE disposal_records
       SET quantity = quantity * ?, unit = 'kg'
       WHERE item_type = 'food' AND lower(item_name) = lower(?) AND lower(unit) = 'portions'`,
      [wasteWeightKgPerPortion, foods[0].name]
    );
    await connection.commit();
    transactionStarted = false;
    return res.json({
      id,
      wasteWeightKgPerPortion,
      convertedRecords: Number(converted.affectedRows),
    });
  } catch (error) {
    if (connection && transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not save food waste weight.' });
  } finally {
    if (connection) connection.release();
  }
});

app.get('/api/food-use-records', async (req, res) => {
  const limit = req.query.limit === undefined ? 100 : Number(req.query.limit);
  const offset = req.query.offset === undefined ? 0 : Number(req.query.offset);
  const status = req.query.status === undefined ? 'all' : String(req.query.status);
  const statusFilters = {
    all: '',
    expiring: `WHERE datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours') > datetime('now')
               AND datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours')
                 <= datetime('now', '+${FOOD_USE_EXPIRING_WINDOW_MINUTES} minutes')`,
    'dispose-now': `WHERE datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours') <= datetime('now')`,
  };
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100
    || !Number.isSafeInteger(offset) || offset < 0
    || !Object.prototype.hasOwnProperty.call(statusFilters, status)) {
    return res.status(400).json({ error: 'Food-use page limit, offset, or status filter is invalid.' });
  }

  try {
    const [countRows] = await database.query(
      `SELECT COUNT(*) AS total,
        SUM(CASE WHEN datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours') > datetime('now')
          AND datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours')
            <= datetime('now', '+${FOOD_USE_EXPIRING_WINDOW_MINUTES} minutes') THEN 1 ELSE 0 END) AS expiring,
        SUM(CASE WHEN datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours') <= datetime('now') THEN 1 ELSE 0 END) AS dispose_now
       FROM food_use_records`
    );
    const counts = {
      all: Number(countRows[0].total),
      expiring: Number(countRows[0].expiring || 0),
      'dispose-now': Number(countRows[0].dispose_now || 0),
    };
    const filteredTotal = counts[status];
    const pageOffset = filteredTotal
      ? Math.min(offset, Math.floor((filteredTotal - 1) / limit) * limit)
      : 0;
    const [records] = await database.query(
      `SELECT id, food_name, portions, used_at, ingredients_used
       FROM food_use_records
       ${statusFilters[status]}
       ORDER BY used_at DESC, id DESC
       LIMIT ? OFFSET ?`,
      [limit, pageOffset]
    );
    return res.json({
      records: records.map((row) => ({
        id: Number(row.id),
        food: row.food_name,
        portions: Number(row.portions),
        usedAt: row.used_at,
        ingredientsUsed: JSON.parse(row.ingredients_used || '[]'),
      })),
      total: counts.all,
      filteredTotal,
      counts,
      limit,
      offset: pageOffset,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load food-use history.' });
  }
});

app.post('/api/food-use-records/dispose', async (req, res) => {
  const ids = req.body?.ids;
  if (!Array.isArray(ids) || ids.length === 0 || ids.length > 100
    || ids.some((id) => !Number.isSafeInteger(id) || id < 1)
    || new Set(ids).size !== ids.length) {
    return res.status(400).json({ error: 'Select between 1 and 100 unique food-use records.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const placeholders = ids.map(() => '?').join(', ');
    const [records] = await connection.query(
      `SELECT id, food_name, portions, used_at
       FROM food_use_records
       WHERE id IN (${placeholders})`,
      ids
    );
    if (records.length !== ids.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'One or more selected food-use records no longer exist.' });
    }

    const [activeRecords] = await connection.query(
      `SELECT id
       FROM food_use_records
       WHERE id IN (${placeholders})
         AND datetime(used_at, '+${FOOD_USE_SHELF_LIFE_HOURS} hours') > datetime('now')`,
      ids
    );
    if (activeRecords.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(400).json({ error: `Only food-use records whose ${FOOD_USE_SHELF_LIFE_HOURS}-hour shelf life has expired can be disposed.` });
    }

    const foodNames = [...new Set(records.map((record) => record.food_name))];
    const foodPlaceholders = foodNames.map(() => '?').join(', ');
    const [foods] = await connection.query(
      `SELECT name, waste_weight_kg_per_portion
       FROM food_items
       WHERE lower(name) IN (${foodPlaceholders})`,
      foodNames.map((foodName) => foodName.toLowerCase())
    );
    const weightByFood = new Map(foods.map((food) => [
      food.name,
      Number(food.waste_weight_kg_per_portion),
    ]));
    const missingWeight = foodNames.find((foodName) => (
      !Number.isFinite(weightByFood.get(foodName)) || weightByFood.get(foodName) <= 0
    ));
    if (missingWeight) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(400).json({
        error: `Set a kg-per-portion weight for ${missingWeight} on the Disposal page before disposing it.`,
      });
    }

    const wasteKgByFood = new Map();
    records.forEach((record) => {
      wasteKgByFood.set(
        record.food_name,
        (wasteKgByFood.get(record.food_name) || 0)
          + (Number(record.portions) * weightByFood.get(record.food_name))
      );
    });
    const disposedAt = new Date().toISOString();
    for (const [foodName, wasteKg] of wasteKgByFood) {
      const roundedWasteKg = Math.round(wasteKg * 1000000) / 1000000;
      wasteKgByFood.set(foodName, roundedWasteKg);
      await connection.query(
        `INSERT INTO disposal_records (item_type, item_name, quantity, unit, disposed_at)
         VALUES ('food', ?, ?, 'kg', ?)`,
        [foodName, roundedWasteKg, disposedAt]
      );
    }
    await connection.query(
      `DELETE FROM food_use_records WHERE id IN (${placeholders})`,
      ids
    );
    await connection.commit();
    transactionStarted = false;
    return res.json({
      disposedRecords: records.length,
      wasteItems: wasteKgByFood.size,
      totalPortions: records.reduce((total, record) => total + Number(record.portions), 0),
      totalWasteKg: [...wasteKgByFood.values()].reduce((total, wasteKg) => total + wasteKg, 0),
    });
  } catch (error) {
    if (connection && transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not bulk dispose the selected food-use records.' });
  } finally {
    if (connection) connection.release();
  }
});

app.post('/api/food-use-records/import', async (req, res) => {
  const records = req.body.records;
  if (!Array.isArray(records) || records.length > 1000 || records.some((record) => (
    !record || typeof record.food !== 'string' || !record.food.trim()
    || !Number.isInteger(Number(record.portions)) || Number(record.portions) < 1
    || typeof record.usedAt !== 'string' || Number.isNaN(new Date(record.usedAt).getTime())
  ))) {
    return res.status(400).json({ error: 'Valid food-use records are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    let imported = 0;
    for (const record of records) {
      const [foodRows] = await connection.query(
        'SELECT id, name FROM food_items WHERE lower(name) = ?',
        [record.food.trim().toLowerCase()]
      );
      if (foodRows.length === 0) continue;

      const [recipeRows] = await connection.query(
        'SELECT ingredient_name, quantity, unit FROM food_recipe_items WHERE food_id = ?',
        [foodRows[0].id]
      );
      const ingredientsUsed = Array.isArray(record.ingredientsUsed)
        ? record.ingredientsUsed
        : recipeRows.map((item) => ({
          name: item.ingredient_name,
          quantity: Number(item.quantity) * Number(record.portions),
          unit: item.unit,
        }));
      const usedAt = new Date(record.usedAt).toISOString();
      const recordData = JSON.stringify(ingredientsUsed);
      const [existingRows] = await connection.query(
        'SELECT id FROM food_use_records WHERE food_name = ? AND portions = ? AND used_at = ? AND ingredients_used = ?',
        [foodRows[0].name, Number(record.portions), usedAt, recordData]
      );
      if (existingRows.length > 0) continue;

      await connection.query(
        'INSERT INTO food_use_records (food_name, portions, used_at, ingredients_used) VALUES (?, ?, ?, ?)',
        [foodRows[0].name, Number(record.portions), usedAt, recordData]
      );
      imported += 1;
    }

    await connection.commit();
    transactionStarted = false;
    return res.json({ imported });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not import food-use history.' });
  } finally {
    if (connection) connection.release();
  }
});

app.post('/api/food-use-records', async (req, res) => {
  const foodName = typeof req.body.food === 'string' ? req.body.food.trim() : '';
  const portions = Number(req.body.portions);
  const usedAt = typeof req.body.usedAt === 'string' && req.body.usedAt ? req.body.usedAt : new Date().toISOString();

  if (!foodName || !Number.isInteger(portions) || portions < 1 || Number.isNaN(new Date(usedAt).getTime())) {
    return res.status(400).json({ error: 'A valid food name, integer portions, and used-at time are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const [foodRows] = await connection.query(
      'SELECT id, name FROM food_items WHERE lower(name) = ?',
      [foodName.toLowerCase()]
    );
    if (foodRows.length === 0) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'Food item not found.' });
    }

    const [recipeRows] = await connection.query(
      'SELECT ingredient_name, quantity, unit FROM food_recipe_items WHERE food_id = ?',
      [foodRows[0].id]
    );

    const ingredientConsumption = recipeRows.map((row) => ({
      name: row.ingredient_name,
      quantity: Number(row.quantity) * portions,
      unit: row.unit,
    }));

    const names = [...new Set(ingredientConsumption.map((item) => item.name.trim().toLowerCase()))];
    const placeholders = names.map(() => '?').join(', ');
    const [stockRows] = await connection.query(
      `SELECT id, name, quantity, unit, pack_size, pack_unit FROM ingredients
       WHERE lower(name) IN (${placeholders})
       ORDER BY lower(name), expires_at IS NULL, expires_at, id`,
      names
    );

    const batchesByName = new Map();
    for (const row of stockRows) {
      const key = String(row.name).trim().toLowerCase();
      if (!batchesByName.has(key)) batchesByName.set(key, []);
      batchesByName.get(key).push({
        id: Number(row.id),
        quantity: Number(row.quantity),
        unit: row.unit,
        pack_size: row.pack_size,
        pack_unit: row.pack_unit,
      });
    }

    if (names.some((name) => !batchesByName.has(name))) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: 'Ingredient stock is unavailable. Check the database connection and try again.' });
    }

    const insufficientItem = ingredientConsumption.find((item) => (
      (batchesByName.get(item.name.trim().toLowerCase()) || [])
        .reduce((total, batch) => total + getBatchQuantityInUnit(batch, item.unit), 0) + 0.000001 < item.quantity
    ));

    if (insufficientItem) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: `Not enough stock: ${insufficientItem.name}.` });
    }

    for (const item of ingredientConsumption) {
      let remaining = item.quantity;
      const batches = batchesByName.get(item.name.trim().toLowerCase()) || [];
      for (const batch of batches) {
        if (remaining <= 0.000001) break;
        const available = getBatchQuantityInUnit(batch, item.unit);
        const deducted = Math.min(available, remaining);
        if (deducted <= 0) continue;
        const stockDeduction = getBatchDeductionInStockUnit(batch, deducted, item.unit);
        await connection.query('UPDATE ingredients SET quantity = quantity - ? WHERE id = ?', [stockDeduction, batch.id]);
        batch.quantity -= stockDeduction;
        remaining -= deducted;
      }
    }

    const [insertResult] = await connection.query(
      'INSERT INTO food_use_records (food_name, portions, used_at, ingredients_used) VALUES (?, ?, ?, ?)',
      [foodName, portions, usedAt, JSON.stringify(ingredientConsumption)]
    );

    await connection.commit();
    transactionStarted = false;
    return res.status(201).json({
      id: Number(insertResult.insertId),
      food: foodName,
      portions,
      usedAt,
      ingredientsUsed: ingredientConsumption,
    });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not record food use.' });
  } finally {
    if (connection) connection.release();
  }
});

app.delete('/api/food-use-records/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ error: 'A valid food-use record ID is required.' });
  }

  try {
    const [result] = await database.query('DELETE FROM food_use_records WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Food-use record not found.' });
    return res.json({ id });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not delete food-use record.' });
  }
});

app.delete('/api/food-use-records', async (req, res) => {
  try {
    const [result] = await database.query('DELETE FROM food_use_records');
    return res.json({ deleted: result.affectedRows });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not clear food-use history.' });
  }
});

const publicPages = [
  '/login.html',
  '/signup.html',
  '/index.html',
  '/inventory.html',
  '/donation-disposal.html',
  '/waste-log.html',
  '/reports-analytics.html',
  '/alerts.html',
  '/settings.html',
];

app.get(['/', ...publicPages], async (req, res) => {
  const page = req.path === '/' ? 'index.html' : req.path.slice(1);
  if (page !== 'login.html' && page !== 'signup.html') {
    try {
      if (!await findSessionUser(req)) return res.redirect('/login.html');
    } catch (error) {
      console.error(error);
      return res.status(503).send('Could not verify your session.');
    }
  }
  return res.sendFile(path.join(__dirname, page));
});

app.get(['/style.css', '/script.js', '/auth.js'], (req, res) => {
  res.sendFile(path.join(__dirname, req.path.slice(1)));
});

app.use(
  '/node_modules/bootstrap-icons/font',
  express.static(path.join(__dirname, 'node_modules', 'bootstrap-icons', 'font'), { index: false })
);

database.initialize().then(() => {
  console.log(`SQLite database: ${database.dbPath}`);
  app.listen(port, '0.0.0.0', () => {
    console.log(`API running at http://localhost:${port}`);
  });
}).catch((error) => {
  console.error('Could not initialize the SQLite database.', error);
  process.exitCode = 1;
});