const express = require('express');
const cors = require('cors');
const {
  createHash,
  randomBytes,
  scrypt: scryptCallback,
  timingSafeEqual,
} = require('crypto');
const { promisify } = require('util');
const path = require('path');
const database = require('./db');

const app = express();
const port = Number(process.env.PORT || 3001);
const scrypt = promisify(scryptCallback);
const SESSION_COOKIE = 'wastewise_session';
const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10kb' }));

function readSessionToken(req) {
  const cookieHeader = req.headers.cookie || '';
  const sessionCookie = cookieHeader
    .split(';')
    .map((cookie) => cookie.trim())
    .find((cookie) => cookie.startsWith(`${SESSION_COOKIE}=`));
  const token = sessionCookie?.slice(SESSION_COOKIE.length + 1);
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}

function hashSessionToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

function setSessionCookie(res, req, token) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_LIFETIME_MS / 1000}${secure}`
  );
}

function clearSessionCookie(res, req) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`
  );
}

async function findSessionUser(req) {
  const token = readSessionToken(req);
  if (!token) return null;

  const [users] = await database.query(
    `SELECT users.id, users.name, users.email
     FROM auth_sessions
     JOIN users ON users.id = auth_sessions.user_id
     WHERE auth_sessions.token_hash = ? AND auth_sessions.expires_at > ?`,
    [hashSessionToken(token), Date.now()]
  );
  return users[0] || null;
}

async function createSession(req, res, userId) {
  const token = randomBytes(32).toString('hex');
  await database.query(
    'INSERT INTO auth_sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)',
    [hashSessionToken(token), userId, Date.now() + SESSION_LIFETIME_MS]
  );
  setSessionCookie(res, req, token);
}

function normalizeEmail(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

function validEmail(email) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function hashPassword(password, salt) {
  return (await scrypt(password, salt, 64)).toString('hex');
}

app.post('/api/auth/signup', async (req, res) => {
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const email = normalizeEmail(body.email);
  const password = typeof body.password === 'string' ? body.password : '';
  if (!name || name.length > 80 || !validEmail(email) || password.length < 8 || password.length > 128) {
    return res.status(400).json({
      error: 'Enter a name, valid email address, and password between 8 and 128 characters.',
    });
  }

  try {
    const salt = randomBytes(16).toString('hex');
    const passwordHash = await hashPassword(password, salt);
    const [result] = await database.query(
      'INSERT INTO users (name, email, password_salt, password_hash) VALUES (?, ?, ?, ?)',
      [name, email, salt, passwordHash]
    );
    return res.status(201).json({ success: true });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'An account with that email already exists.' });
    }
    console.error(error);
    return res.status(500).json({ error: 'Could not create your account.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const body = req.body || {};
  const email = normalizeEmail(body.email);
  const password = typeof body.password === 'string' ? body.password : '';
  if (!validEmail(email) || !password || password.length > 128) {
    return res.status(400).json({ error: 'Enter a valid email address and password.' });
  }

  try {
    const [users] = await database.query(
      'SELECT id, name, email, password_salt, password_hash FROM users WHERE email = ?',
      [email]
    );
    const user = users[0];
    if (!user) return res.status(401).json({ error: 'Email or password is incorrect.' });

    const passwordHash = await hashPassword(password, user.password_salt);
    const expectedHash = Buffer.from(user.password_hash, 'hex');
    const actualHash = Buffer.from(passwordHash, 'hex');
    if (expectedHash.length !== actualHash.length || !timingSafeEqual(expectedHash, actualHash)) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }

    await createSession(req, res, user.id);
    return res.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not sign in.' });
  }
});

app.get('/api/auth/me', async (req, res) => {
  try {
    const user = await findSessionUser(req);
    if (!user) return res.status(401).json({ error: 'Please sign in to continue.' });
    return res.json({ user });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not verify your session.' });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  try {
    const token = readSessionToken(req);
    if (token) {
      await database.query('DELETE FROM auth_sessions WHERE token_hash = ?', [hashSessionToken(token)]);
    }
    clearSessionCookie(res, req);
    return res.json({ success: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not sign out.' });
  }
});

app.get('/api/health', async (req, res) => {
  try {
    await database.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (error) {
    console.error(error);
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

app.use('/api', async (req, res, next) => {
  try {
    const user = await findSessionUser(req);
    if (!user) return res.status(401).json({ error: 'Please sign in to continue.' });
    req.user = user;
    return next();
  } catch (error) {
    console.error(error);
    return res.status(503).json({ error: 'Could not verify your session.' });
  }
});

app.get('/api/ingredients', async (req, res) => {
  try {
    const [ingredients] = await database.query(
      'SELECT * FROM ingredients ORDER BY name'
    );

    res.json(ingredients);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

app.post('/api/ingredients', async (req, res) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const quantity = Number(req.body.quantity);
    const expiresAt = parseExpiryDate(req.body.expiresAt);
    if (!name || name.length > 100 || !Number.isFinite(quantity) || quantity < 0 || expiresAt === false) {
      return res.status(400).json({ error: 'Name, a non-negative quantity, and a valid expiry time are required.' });
    }

    const [result] = await database.query(
      `INSERT INTO ingredients (name, quantity, expires_at)
       VALUES (?, ?, ?)`,
      [name, quantity, expiresAt]
    );

    return res.status(201).json({
      id: result.insertId,
      name,
      unit: 'kg',
      quantity: Number(quantity),
      expires_at: expiresAt,
      minimum_quantity: 0
    });
  } catch (error) {
    console.error(error);
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That ingredient already exists.' });
    return res.status(500).json({ error: 'Could not add ingredient.' });
  }
});

app.post('/api/ingredients/consume', async (req, res) => {
  const items = req.body.items;
  if (!Array.isArray(items) || items.length === 0 || items.some((item) => (
    !item || typeof item !== 'object'
    || !Number.isInteger(Number(item.id)) || Number(item.id) < 1
    || !Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0
  )) || new Set(items.map((item) => Number(item.id))).size !== items.length) {
    return res.status(400).json({ error: 'Valid ingredient IDs and positive quantities are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const ids = items.map((item) => Number(item.id));
    const placeholders = ids.map(() => '?').join(', ');
    const [stocks] = await connection.query(
      `SELECT id, quantity FROM ingredients WHERE id IN (${placeholders})`,
      ids
    );
    if (stocks.length !== items.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'One or more ingredients were not found.' });
    }

    const stockById = new Map(stocks.map((stock) => [Number(stock.id), Number(stock.quantity)]));
    const insufficientItem = items.find((item) => (
      stockById.get(Number(item.id)) + 0.000001 < Number(item.quantity)
    ));
    if (insufficientItem) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: `Not enough stock for ingredient ${insufficientItem.id}.` });
    }

    for (const item of items) {
      await connection.query(
        'UPDATE ingredients SET quantity = quantity - ? WHERE id = ?',
        [Number(item.quantity), Number(item.id)]
      );
    }

    const [updatedIngredients] = await connection.query(
      `SELECT id, quantity FROM ingredients WHERE id IN (${placeholders})`,
      ids
    );
    await connection.commit();
    transactionStarted = false;
    return res.json({
      ingredients: updatedIngredients.map((ingredient) => ({
        id: Number(ingredient.id),
        quantity: Number(ingredient.quantity),
      })),
    });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not deduct ingredient stock.' });
  } finally {
    if (connection) connection.release();
  }
});

app.put('/api/ingredients/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : null;
    const quantity = Number(req.body.quantity);
    const hasExpiry = Object.prototype.hasOwnProperty.call(req.body, 'expiresAt');
    const expiresAt = hasExpiry ? parseExpiryDate(req.body.expiresAt) : undefined;
    if (!Number.isInteger(id) || id < 1 || !Number.isFinite(quantity) || quantity < 0 || expiresAt === false || (name !== null && (!name || name.length > 100))) {
      return res.status(400).json({ error: 'A valid ingredient ID, name, non-negative quantity, and expiry time are required.' });
    }

    const fields = name === null ? ['quantity = ?'] : ['name = ?', 'quantity = ?'];
    const values = name === null ? [quantity] : [name, quantity];
    if (hasExpiry) {
      fields.push('expires_at = ?');
      values.push(expiresAt);
    }
    await database.query(`UPDATE ingredients SET ${fields.join(', ')} WHERE id = ?`, [...values, id]);

    const [rows] = await database.query('SELECT * FROM ingredients WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Ingredient not found.' });
    return res.json(rows[0]);
  } catch (error) {
    console.error(error);
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That ingredient name already exists.' });
    return res.status(500).json({ error: 'Could not update ingredient.' });
  }
});

app.delete('/api/ingredients/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) {
      return res.status(400).json({ error: 'A valid ingredient ID is required.' });
    }

    const [result] = await database.query('DELETE FROM ingredients WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Ingredient not found.' });
    return res.json({ id });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not remove ingredient.' });
  }
});

function parseExpiryDate(value) {
  if (value === undefined || value === null || value === '') return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? false : date.toISOString();
}

app.post('/api/ingredients/:id/dispose', async (req, res) => {
  const connection = await database.getConnection();
  let transactionStarted = false;
  try {
    const id = Number(req.params.id);
    const quantity = Number(req.body.quantity);
    const unit = typeof req.body.unit === 'string' ? req.body.unit.trim() : 'kg';
    if (!Number.isInteger(id) || id < 1 || !Number.isFinite(quantity) || quantity <= 0 || !unit || unit.length > 20) {
      return res.status(400).json({ error: 'A valid ingredient ID and positive disposal quantity are required.' });
    }

    await connection.beginTransaction();
    transactionStarted = true;
    const [ingredients] = await connection.query(
      'SELECT id, name, quantity FROM ingredients WHERE id = ?',
      [id]
    );
    if (ingredients.length === 0) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'Ingredient not found.' });
    }
    if (Number(ingredients[0].quantity) + 0.000001 < quantity) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: 'Stock changed before disposal. Refresh inventory and try again.' });
    }

    await connection.query('UPDATE ingredients SET quantity = quantity - ? WHERE id = ?', [quantity, id]);
    await connection.query(
      'INSERT INTO disposal_records (item_type, item_name, quantity, unit) VALUES (?, ?, ?, ?)',
      ['ingredient', ingredients[0].name, quantity, unit]
    );

    const [rows] = await connection.query('SELECT id, quantity FROM ingredients WHERE id = ?', [id]);
    await connection.commit();
    transactionStarted = false;
    return res.json({ id, quantity: Number(rows[0].quantity) });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not dispose ingredient stock.' });
  } finally {
    connection.release();
  }
});

app.post('/api/disposals', async (req, res) => {
  const items = req.body.items;
  if (!Array.isArray(items) || items.length === 0 || items.some((item) => (
    !item || item.itemType !== 'food'
    || typeof item.itemName !== 'string' || !item.itemName.trim() || item.itemName.trim().length > 100
    || !Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0
    || typeof item.unit !== 'string' || !item.unit.trim() || item.unit.trim().length > 20
  ))) {
    return res.status(400).json({ error: 'Valid food names, positive quantities, and units are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;
    for (const item of items) {
      await connection.query(
        'INSERT INTO disposal_records (item_type, item_name, quantity, unit) VALUES (?, ?, ?, ?)',
        ['food', item.itemName.trim(), Number(item.quantity), item.unit.trim()]
      );
    }
    await connection.commit();
    transactionStarted = false;
    return res.status(201).json({ recorded: items.length });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not save disposal records.' });
  } finally {
    if (connection) connection.release();
  }
});

app.get('/api/disposals', async (req, res) => {
  try {
    const [records] = await database.query(
      'SELECT id, item_type, item_name, quantity, unit, disposed_at FROM disposal_records ORDER BY disposed_at DESC LIMIT 100'
    );
    return res.json(records);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load disposal records.' });
  }
});

app.get('/api/food-items', async (req, res) => {
  try {
    const [foods] = await database.query(
      'SELECT id, name FROM food_items ORDER BY name'
    );
    const [recipeRows] = await database.query(
      'SELECT food_id, ingredient_name, quantity, unit FROM food_recipe_items ORDER BY food_id, ingredient_name'
    );

    const recipeMap = new Map();
    recipeRows.forEach((row) => {
      if (!recipeMap.has(Number(row.food_id))) {
        recipeMap.set(Number(row.food_id), []);
      }
      recipeMap.get(Number(row.food_id)).push({
        name: row.ingredient_name,
        quantity: Number(row.quantity),
        unit: row.unit,
      });
    });

    return res.json(foods.map((food) => ({
      id: Number(food.id),
      name: food.name,
      recipe: recipeMap.get(Number(food.id)) || [],
    })));
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load food items.' });
  }
});

app.get('/api/food-use-records', async (req, res) => {
  try {
    const [records] = await database.query(
      'SELECT id, food_name, portions, used_at, ingredients_used FROM food_use_records ORDER BY used_at DESC'
    );
    return res.json(records.map((row) => ({
      id: Number(row.id),
      food: row.food_name,
      portions: Number(row.portions),
      usedAt: row.used_at,
      ingredientsUsed: JSON.parse(row.ingredients_used || '[]'),
    })));
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not load food-use history.' });
  }
});

app.post('/api/food-use-records/import', async (req, res) => {
  const records = req.body.records;
  if (!Array.isArray(records) || records.length > 1000 || records.some((record) => (
    !record || typeof record.food !== 'string' || !record.food.trim()
    || !Number.isInteger(Number(record.portions)) || Number(record.portions) < 1
    || typeof record.usedAt !== 'string' || Number.isNaN(new Date(record.usedAt).getTime())
  ))) {
    return res.status(400).json({ error: 'Valid food-use records are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    let imported = 0;
    for (const record of records) {
      const [foodRows] = await connection.query(
        'SELECT id, name FROM food_items WHERE lower(name) = ?',
        [record.food.trim().toLowerCase()]
      );
      if (foodRows.length === 0) continue;

      const [recipeRows] = await connection.query(
        'SELECT ingredient_name, quantity, unit FROM food_recipe_items WHERE food_id = ?',
        [foodRows[0].id]
      );
      const ingredientsUsed = Array.isArray(record.ingredientsUsed)
        ? record.ingredientsUsed
        : recipeRows.map((item) => ({
          name: item.ingredient_name,
          quantity: Number(item.quantity) * Number(record.portions),
          unit: item.unit,
        }));
      const usedAt = new Date(record.usedAt).toISOString();
      const recordData = JSON.stringify(ingredientsUsed);
      const [existingRows] = await connection.query(
        'SELECT id FROM food_use_records WHERE food_name = ? AND portions = ? AND used_at = ? AND ingredients_used = ?',
        [foodRows[0].name, Number(record.portions), usedAt, recordData]
      );
      if (existingRows.length > 0) continue;

      await connection.query(
        'INSERT INTO food_use_records (food_name, portions, used_at, ingredients_used) VALUES (?, ?, ?, ?)',
        [foodRows[0].name, Number(record.portions), usedAt, recordData]
      );
      imported += 1;
    }

    await connection.commit();
    transactionStarted = false;
    return res.json({ imported });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not import food-use history.' });
  } finally {
    if (connection) connection.release();
  }
});

app.post('/api/food-use-records', async (req, res) => {
  const foodName = typeof req.body.food === 'string' ? req.body.food.trim() : '';
  const portions = Number(req.body.portions);
  const usedAt = typeof req.body.usedAt === 'string' && req.body.usedAt ? req.body.usedAt : new Date().toISOString();

  if (!foodName || !Number.isInteger(portions) || portions < 1 || Number.isNaN(new Date(usedAt).getTime())) {
    return res.status(400).json({ error: 'A valid food name, integer portions, and used-at time are required.' });
  }

  let connection;
  let transactionStarted = false;
  try {
    connection = await database.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    const [foodRows] = await connection.query(
      'SELECT id, name FROM food_items WHERE lower(name) = ?',
      [foodName.toLowerCase()]
    );
    if (foodRows.length === 0) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(404).json({ error: 'Food item not found.' });
    }

    const [recipeRows] = await connection.query(
      'SELECT ingredient_name, quantity, unit FROM food_recipe_items WHERE food_id = ?',
      [foodRows[0].id]
    );

    const ingredientConsumption = recipeRows.map((row) => ({
      name: row.ingredient_name,
      quantity: Number(row.quantity) * portions,
      unit: row.unit,
    }));

    const names = ingredientConsumption.map((item) => item.name.toLowerCase());
    const placeholders = names.map(() => '?').join(', ');
    const [stockRows] = await connection.query(
      `SELECT id, name, quantity FROM ingredients WHERE lower(name) IN (${placeholders})`,
      names
    );

    if (stockRows.length !== ingredientConsumption.length) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: 'Ingredient stock is unavailable. Check the database connection and try again.' });
    }

    const stockByName = new Map(stockRows.map((row) => [String(row.name).trim().toLowerCase(), Number(row.quantity)]));
    const insufficientItem = ingredientConsumption.find((item) => (
      (stockByName.get(item.name.trim().toLowerCase()) ?? 0) + 0.000001 < item.quantity
    ));

    if (insufficientItem) {
      await connection.rollback();
      transactionStarted = false;
      return res.status(409).json({ error: `Not enough stock: ${insufficientItem.name}.` });
    }

    for (const item of ingredientConsumption) {
      await connection.query(
        'UPDATE ingredients SET quantity = quantity - ? WHERE lower(name) = ?',
        [item.quantity, item.name.trim().toLowerCase()]
      );
    }

    const [insertResult] = await connection.query(
      'INSERT INTO food_use_records (food_name, portions, used_at, ingredients_used) VALUES (?, ?, ?, ?)',
      [foodName, portions, usedAt, JSON.stringify(ingredientConsumption)]
    );

    await connection.commit();
    transactionStarted = false;
    return res.status(201).json({
      id: Number(insertResult.insertId),
      food: foodName,
      portions,
      usedAt,
      ingredientsUsed: ingredientConsumption,
    });
  } catch (error) {
    if (transactionStarted) await connection.rollback();
    console.error(error);
    return res.status(500).json({ error: 'Could not record food use.' });
  } finally {
    if (connection) connection.release();
  }
});

app.delete('/api/food-use-records/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ error: 'A valid food-use record ID is required.' });
  }

  try {
    const [result] = await database.query('DELETE FROM food_use_records WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Food-use record not found.' });
    return res.json({ id });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Could not delete food-use record.' });
  }
});

const publicPages = [
  '/login.html',
  '/signup.html',
  '/index.html',
  '/inventory.html',
  '/donation-disposal.html',
  '/waste-log.html',
  '/reports-analytics.html',
  '/alerts.html',
  '/settings.html',
];

app.get(['/', ...publicPages], async (req, res) => {
  const page = req.path === '/' ? 'index.html' : req.path.slice(1);
  if (page !== 'login.html' && page !== 'signup.html') {
    try {
      if (!await findSessionUser(req)) return res.redirect('/login.html');
    } catch (error) {
      console.error(error);
      return res.status(503).send('Could not verify your session.');
    }
  }
  return res.sendFile(path.join(__dirname, page));
});

app.get(['/style.css', '/script.js', '/auth.js'], (req, res) => {
  res.sendFile(path.join(__dirname, req.path.slice(1)));
});

app.use(
  '/node_modules/bootstrap-icons/font',
  express.static(path.join(__dirname, 'node_modules', 'bootstrap-icons', 'font'), { index: false })
);

database.initialize().then(() => {
  console.log(`SQLite database: ${database.dbPath}`);
  app.listen(port, () => {
    console.log(`API running at http://localhost:${port}`);
  });
}).catch((error) => {
  console.error('Could not initialize the SQLite database.', error);
  process.exitCode = 1;
});