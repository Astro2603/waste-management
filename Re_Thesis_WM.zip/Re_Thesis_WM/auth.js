const apiBaseUrl = window.WASTEWISE_API_URL || 'http://localhost:3001/api';
const appBaseUrl = new URL(apiBaseUrl).origin;
const authForm = document.querySelector('#login-form, #signup-form');
const authMessage = document.querySelector('#auth-message');

async function readAuthResponse(response, pageName) {
  const responseText = await response.text();
  if (!responseText) {
    throw new Error(
      `The server returned an empty response (HTTP ${response.status}). `
      + `Make sure the WasteWise server is running, then open `
      + `http://localhost:3001/${pageName}.html.`
    );
  }

  let result;
  try {
    result = JSON.parse(responseText);
  } catch {
    throw new Error(
      `The server returned an unreadable response (HTTP ${response.status}). `
      + `Make sure the WasteWise server is running, then open `
      + `http://localhost:3001/${pageName}.html.`
    );
  }

  if (!response.ok) {
    throw new Error(result.error || 'Could not complete your request.');
  }
  return result;
}

authForm?.addEventListener('submit', async (event) => {
  event.preventDefault();

  const isSignup = authForm.id === 'signup-form';
  const pageName = isSignup ? 'signup' : 'login';
  const submitButton = authForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  authMessage.textContent = '';
  authMessage.classList.remove('success');

  try {
    const response = await fetch(`${apiBaseUrl}/auth/${pageName}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(Object.fromEntries(new FormData(authForm).entries())),
    });
    const result = await readAuthResponse(response, pageName);

    if (isSignup) {
      authMessage.textContent = 'Account created. Please sign in to continue.';
      authMessage.classList.add('success');
      authForm.reset();
      return;
    }

    if (!result.user) {
      throw new Error('The server response did not include an account. Please try again.');
    }

    authMessage.textContent = 'Success. Redirecting to your dashboard…';
    authMessage.classList.add('success');
    window.location.assign(`${appBaseUrl}/`);
  } catch (error) {
    authMessage.textContent = error instanceof TypeError
      ? `Could not connect to the WasteWise server. Start it with "node server.js", `
        + `then open http://localhost:3001/${pageName}.html.`
      : (error.message || 'Could not complete your request. Please try again.');
  } finally {
    submitButton.disabled = false;
  }
});
