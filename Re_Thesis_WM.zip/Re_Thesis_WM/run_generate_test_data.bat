@echo off
python "%~dp0generate_test_data.py" %*
exit /b %ERRORLEVEL%
