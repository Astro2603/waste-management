"""Generate a deterministic synthetic SQLite dataset for testing WasteWise."""

from __future__ import annotations

import argparse
import json
import math
import random
import sqlite3
from datetime import datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any


PROJECT_DIR = Path(__file__).resolve().parent
SCHEMA_FILE = PROJECT_DIR / "schema.sql"
DEFAULT_DATABASE = PROJECT_DIR / "wastewise.sqlite"

FOOD_CATALOG = {
    "Burger": [
        {"name": "Beef patty", "quantity": 0.20, "unit": "kg"},
        {"name": "Burger buns", "quantity": 1, "unit": "pcs"},
        {"name": "Lettuce", "quantity": 0.05, "unit": "kg"},
        {"name": "Tomato", "quantity": 0.07, "unit": "kg"},
        {"name": "Cheese", "quantity": 0.02, "unit": "kg"},
    ],
    "Chicken": [
        {"name": "Chicken", "quantity": 0.20, "unit": "kg"},
        {"name": "Fried chicken batter", "quantity": 0.06, "unit": "kg"},
        {"name": "Cooking oil", "quantity": 0.05, "unit": "L"},
        {"name": "Spices", "quantity": 0.01, "unit": "kg"},
    ],
    "Spaghetti": [
        {"name": "Pasta", "quantity": 0.20, "unit": "kg"},
        {"name": "Tomato sauce", "quantity": 0.10, "unit": "L"},
        {"name": "Ground beef", "quantity": 0.11, "unit": "kg"},
        {"name": "Cheese", "quantity": 0.02, "unit": "kg"},
    ],
}

INGREDIENT_UNITS = {
    ingredient["name"]: ingredient["unit"]
    for recipe in FOOD_CATALOG.values()
    for ingredient in recipe
}


def iso_timestamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds")


def random_timestamp(rng: random.Random, day: datetime, now: datetime) -> datetime:
    end_of_day = day + timedelta(days=1, seconds=-1)
    latest = min(end_of_day, now)
    seconds_available = max(0, int((latest - day).total_seconds()))
    return day + timedelta(seconds=rng.randint(0, seconds_available))


def build_dataset(
    rng: random.Random,
    days: int,
    events_per_day: int,
    now: datetime,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    events: list[dict[str, Any]] = []
    ingredient_totals = {name: 0.0 for name in INGREDIENT_UNITS}

    first_day = datetime.combine(
        now.date() - timedelta(days=days - 1), time.min, tzinfo=timezone.utc
    )
    for day_offset in range(days):
        day_start = first_day + timedelta(days=day_offset)
        if events_per_day:
            minimum_events = max(1, events_per_day - 3)
            event_count = rng.randint(minimum_events, events_per_day + 3)
        else:
            event_count = 0

        for _ in range(event_count):
            food_name = rng.choice(list(FOOD_CATALOG))
            portions = rng.randint(1, 8)
            used_at = random_timestamp(rng, day_start, now)
            recipe_snapshot = []
            for ingredient in FOOD_CATALOG[food_name]:
                quantity = round(ingredient["quantity"] * portions, 4)
                ingredient_totals[ingredient["name"]] += quantity
                recipe_snapshot.append({
                    "name": ingredient["name"],
                    "quantity": quantity,
                    "unit": ingredient["unit"],
                })
            events.append({
                "type": "food_use",
                "at": used_at,
                "food": food_name,
                "portions": portions,
                "ingredients": recipe_snapshot,
            })

        for _ in range(rng.randint(0, 3)):
            disposed_at = random_timestamp(rng, day_start, now)
            if rng.random() < 0.65:
                ingredient_name = rng.choice(list(INGREDIENT_UNITS))
                quantity = round(rng.uniform(0.02, 0.50), 2)
                ingredient_totals[ingredient_name] += quantity
                events.append({
                    "type": "ingredient_disposal",
                    "at": disposed_at,
                    "name": ingredient_name,
                    "quantity": quantity,
                    "unit": INGREDIENT_UNITS[ingredient_name],
                })
            else:
                events.append({
                    "type": "food_disposal",
                    "at": disposed_at,
                    "name": rng.choice(list(FOOD_CATALOG)),
                    "quantity": rng.randint(1, 6),
                    "unit": "portions",
                })

    events.sort(key=lambda event: event["at"])
    opening_stock = {}
    for name, required in ingredient_totals.items():
        opening_quantity = required * 1.20 + 2
        if INGREDIENT_UNITS[name] == "pcs":
            opening_stock[name] = float(math.ceil(opening_quantity))
        else:
            opening_stock[name] = round(opening_quantity, 2)
    return events, [{"name": name, "quantity": quantity} for name, quantity in opening_stock.items()]


def reset_schema(connection: sqlite3.Connection) -> None:
    connection.executescript("""
        DROP TABLE IF EXISTS food_use_records;
        DROP TABLE IF EXISTS disposal_records;
        DROP TABLE IF EXISTS food_recipe_items;
        DROP TABLE IF EXISTS food_items;
        DROP TABLE IF EXISTS ingredients;
    """)
    connection.executescript(SCHEMA_FILE.read_text(encoding="utf-8"))


def populate_database(
    connection: sqlite3.Connection,
    rng: random.Random,
    days: int,
    events_per_day: int,
) -> tuple[int, int, int]:
    now = datetime.now(timezone.utc)
    events, opening_stock = build_dataset(rng, days, events_per_day, now)
    current_stock = {item["name"]: item["quantity"] for item in opening_stock}

    for ingredient in opening_stock:
        expiry_offset = rng.choice([None, -5, -2, 1, 3, 7, 14, 30])
        expires_at = None
        if expiry_offset is not None:
            expires_at = iso_timestamp(now + timedelta(days=expiry_offset))
        connection.execute(
            "INSERT INTO ingredients (name, quantity, expires_at) VALUES (?, ?, ?)",
            (ingredient["name"], ingredient["quantity"], expires_at),
        )

    food_ids = {}
    for food_name, recipe in FOOD_CATALOG.items():
        cursor = connection.execute("INSERT INTO food_items (name) VALUES (?)", (food_name,))
        food_id = int(cursor.lastrowid)
        food_ids[food_name] = food_id
        connection.executemany(
            """INSERT INTO food_recipe_items
               (food_id, ingredient_name, quantity, unit) VALUES (?, ?, ?, ?)""",
            [
                (food_id, item["name"], item["quantity"], item["unit"])
                for item in recipe
            ],
        )

    food_use_count = 0
    disposal_count = 0
    for event in events:
        timestamp = iso_timestamp(event["at"])
        if event["type"] == "food_use":
            for ingredient in event["ingredients"]:
                current_stock[ingredient["name"]] -= ingredient["quantity"]
            connection.execute(
                """INSERT INTO food_use_records
                   (food_name, portions, used_at, ingredients_used)
                   VALUES (?, ?, ?, ?)""",
                (
                    event["food"],
                    event["portions"],
                    timestamp,
                    json.dumps(event["ingredients"], separators=(",", ":")),
                ),
            )
            food_use_count += 1
        elif event["type"] == "ingredient_disposal":
            name = event["name"]
            current_stock[name] -= event["quantity"]
            connection.execute(
                "UPDATE ingredients SET quantity = ? WHERE name = ?",
                (round(current_stock[name], 4), name),
            )
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES ('ingredient', ?, ?, ?, ?)""",
                (name, event["quantity"], event["unit"], timestamp),
            )
            disposal_count += 1
        else:
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES ('food', ?, ?, ?, ?)""",
                (event["name"], event["quantity"], event["unit"], timestamp),
            )
            disposal_count += 1

    return len(opening_stock), len(food_ids), food_use_count + disposal_count


def append_history(
    connection: sqlite3.Connection,
    rng: random.Random,
    days: int,
    events_per_day: int,
) -> int:
    required_tables = {"food_items", "food_use_records", "disposal_records"}
    existing_tables = {
        row[0]
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }
    missing_tables = required_tables - existing_tables
    if missing_tables:
        raise ValueError(
            "The target is missing WasteWise tables: " + ", ".join(sorted(missing_tables))
        )

    food_names = {
        row[0].strip().lower()
        for row in connection.execute("SELECT name FROM food_items")
    }
    missing_foods = set(FOOD_CATALOG) - {name.title() for name in food_names}
    if missing_foods:
        raise ValueError(
            "Add the default food catalog before appending history; missing: "
            + ", ".join(sorted(missing_foods))
        )

    events, _ = build_dataset(rng, days, events_per_day, datetime.now(timezone.utc))
    for event in events:
        timestamp = iso_timestamp(event["at"])
        if event["type"] == "food_use":
            connection.execute(
                """INSERT INTO food_use_records
                   (food_name, portions, used_at, ingredients_used)
                   VALUES (?, ?, ?, ?)""",
                (
                    event["food"],
                    event["portions"],
                    timestamp,
                    json.dumps(event["ingredients"], separators=(",", ":")),
                ),
            )
        else:
            item_type = "ingredient" if event["type"] == "ingredient_disposal" else "food"
            connection.execute(
                """INSERT INTO disposal_records
                   (item_type, item_name, quantity, unit, disposed_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    item_type,
                    event["name"],
                    event["quantity"],
                    event["unit"],
                    timestamp,
                ),
            )
    return len(events)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create deterministic synthetic data in a separate WasteWise SQLite database."
    )
    parser.add_argument("--db", type=Path, default=DEFAULT_DATABASE,
                        help=f"output database path (default: {DEFAULT_DATABASE.name})")
    parser.add_argument("--days", type=int, default=30,
                        help="number of calendar days to generate (1-365; default: 30)")
    parser.add_argument("--events-per-day", type=int, default=8,
                        help="approximate food-use records per day (0-100; default: 8)")
    parser.add_argument("--seed", type=int, default=42,
                        help="random seed for repeatable data (default: 42)")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--append", action="store_true",
                      help="append synthetic history to an existing database without changing stock")
    parser.add_argument("--reset", action="store_true",
                        help="replace WasteWise tables in the target database if it exists")
    args = parser.parse_args()
    if not 1 <= args.days <= 365:
        parser.error("--days must be between 1 and 365")
    if not 0 <= args.events_per_day <= 100:
        parser.error("--events-per-day must be between 0 and 100")
    if args.append and not args.db.is_file():
        parser.error(f"{args.db} does not exist; use --reset to create a new database")
    if args.db.exists() and args.db.stat().st_size > 0 and not (args.append or args.reset):
        parser.error(f"{args.db} already exists; pass --append to preserve data or --reset to replace it")
    return args


def main() -> None:
    args = parse_args()
    args.db.parent.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)

    connection = sqlite3.connect(args.db)
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        with connection:
            if args.append:
                event_count = append_history(connection, rng, args.days, args.events_per_day)
            else:
                reset_schema(connection)
                populate_database(connection, rng, args.days, args.events_per_day)
        totals = {
            table: connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in (
                "ingredients",
                "food_items",
                "food_recipe_items",
                "food_use_records",
                "disposal_records",
            )
        }
    finally:
        connection.close()

    print(f"Synthetic dataset created: {args.db.resolve()}")
    print(f"Seed: {args.seed}; days: {args.days}; events per day: {args.events_per_day}")
    if args.append:
        print(f"Appended history events: {event_count}; inventory quantities were not changed.")
    print("Rows: " + ", ".join(f"{table}={count}" for table, count in totals.items()))


if __name__ == "__main__":
    main()