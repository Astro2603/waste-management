// Shared controls used by every page.
const menuToggle = document.querySelector('.menu-toggle');
const sidebar = document.querySelector('.sidebar');
const reportButtons = document.querySelectorAll('.report-button, .wasted-panel .text-button, .insights-panel .outline-button');
const navItems = document.querySelectorAll('.nav-item');
const themeToggle = document.querySelector('.theme-toggle');
const API_BASE_URL = window.WASTEWISE_API_URL || `${window.location.origin}/api`;

// Keep all browser-to-server requests consistent.
async function requestAPI(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    credentials: 'include',
    ...options,
  });
  const body = await response.json().catch(() => ({}));
  if (response.status === 401) {
    window.location.assign('/login.html');
    throw new Error(body.error || 'Please sign in to continue.');
  }
  if (!response.ok) throw new Error(body.error || 'The server request failed.');
  return body;
}

const profile = document.querySelector('.profile');
if (profile) {
  const existingLogoutButton = profile.querySelector('.profile-logout');
  const logoutButton = existingLogoutButton || document.createElement('button');

  logoutButton.type = 'button';
  logoutButton.className = 'profile-logout';
  logoutButton.innerHTML = '<i class="bi bi-box-arrow-right" aria-hidden="true"></i><span>Sign out</span>';
  logoutButton.setAttribute('aria-label', 'Sign out');
  logoutButton.title = 'Sign out';
  logoutButton.disabled = false;
  logoutButton.onclick = async () => {
    logoutButton.disabled = true;
    try {
      await requestAPI('/auth/logout', { method: 'POST' });
      window.location.assign('/login.html');
    } catch (error) {
      logoutButton.disabled = false;
      console.error(error);
    }
  };

  if (!existingLogoutButton) profile.append(logoutButton);

  requestAPI('/auth/me').then(({ user }) => {
    const details = profile.querySelector('div:nth-child(2)');
    if (details) {
      details.querySelector('strong').textContent = user.name;
      details.querySelector('small').textContent = user.email;
    }
  }).catch((error) => {
    if (error.message !== 'Please sign in to continue.') console.error(error);
  });
}

// Restore and apply the user's display theme.
function applyTheme(isDark) {
  document.body.classList.toggle('dark-mode', isDark);
  if (!themeToggle) return;
  themeToggle.setAttribute('aria-pressed', String(isDark));
  themeToggle.innerHTML = `<i class="bi ${isDark ? 'bi-sun' : 'bi-moon-stars'}"></i><span>${isDark ? 'Light Mode' : 'Dark Mode'}</span>`;
}

applyTheme(localStorage.getItem('wasteWiseTheme') === 'dark');

if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    const isDark = !document.body.classList.contains('dark-mode');
    localStorage.setItem('wasteWiseTheme', isDark ? 'dark' : 'light');
    applyTheme(isDark);
  });
}

// Collapse the sidebar on desktop and slide it open on mobile.
menuToggle.addEventListener('click', () => {
  if (window.innerWidth <= 720) {
    sidebar.classList.toggle('open');
  } else {
    sidebar.classList.toggle('collapsed');
  }
  menuToggle.setAttribute('aria-expanded', String(
    window.innerWidth <= 720 ? sidebar.classList.contains('open') : !sidebar.classList.contains('collapsed'),
  ));
});

navItems.forEach((item) => {
  item.addEventListener('click', () => {
    navItems.forEach((navItem) => navItem.classList.remove('active'));
    item.classList.add('active');
    if (window.innerWidth <= 720) sidebar.classList.remove('open');
  });
});

reportButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const originalText = button.innerHTML;
    button.innerHTML = 'Report opened <b>✓</b>';
    window.setTimeout(() => { button.innerHTML = originalText; }, 1200);
  });
});

const legacyStarterWasteLogs = new Set([
  '2026-09-01|10.8|340|28',
  '2026-09-02|11.6|365|29',
  '2026-09-03|12.2|390|30',
  '2026-09-04|13.1|420|31',
  '2026-09-05|14.4|460|32',
  '2026-09-06|13.7|440|30',
  '2026-09-07|12.9|405|29',
  '2026-09-08|14.1|450|31',
  '2026-09-09|15.2|480|33',
  '2026-09-10|13.5|430|30',
]);

function getStoredWasteLogs() {
  try {
    const logs = JSON.parse(localStorage.getItem('wasteWiseLogs') || '[]');
      const realLogs = logs.filter((log) => !legacyStarterWasteLogs.has(
      `${log.date}|${Number(log.wasteKg)}|${Number(log.mealsServed)}|${Number(log.temperature)}`,
    ));
    if (realLogs.length !== logs.length) saveWasteLogs(realLogs);
    return realLogs;
  } catch {
    return [];
  }
}

function getWasteLogs() {
  return getStoredWasteLogs();
}

function formatDate(date) {
  return new Intl.DateTimeFormat('en', { month: 'long', day: 'numeric', year: 'numeric' }).format(new Date(`${date}T00:00:00`));
}

function saveWasteLogs(logs) {
  localStorage.setItem('wasteWiseLogs', JSON.stringify(logs));
}

async function renderDisposalWasteLogs() {
  const rows = document.querySelector('#disposal-log-rows, #report-disposal-rows');
  const count = document.querySelector('#disposal-log-count, #report-disposal-count');
  if (!rows || !count) return;
  try {
    const records = await requestAPI('/disposals');
    count.textContent = `${records.length} record${records.length === 1 ? '' : 's'}`;
    rows.innerHTML = records.length
      ? records.map((record) => `<tr><td>${formatDateTime(new Date(record.disposed_at))}</td><td><strong>${escapeHTML(record.item_name)}</strong></td><td>${record.item_type === 'ingredient' ? 'Ingredient' : 'Food'}</td><td>${Number(record.quantity).toLocaleString('en', { maximumFractionDigits: 2 })} ${escapeHTML(record.unit)}</td></tr>`).join('')
      : '<tr><td colspan="4" class="table-message">No disposed items have been recorded yet.</td></tr>';
  } catch (error) {
    count.textContent = 'Unavailable';
    rows.innerHTML = `<tr><td colspan="4" class="table-message">${escapeHTML(error.message)}</td></tr>`;
  }
}

renderDisposalWasteLogs();

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character]);
}

const inventoryStockRows = document.querySelector('#inventory-stock-rows');
const inventoryFoodRows = document.querySelector('#inventory-food-rows');

let inventoryFoods = [
  {
    name: 'Burger',
    recipe: [
      { name: 'Beef patty', quantity: 0.20 },
      { name: 'Burger buns', quantity: 1 },
      { name: 'Lettuce', quantity: 0.05 },
      { name: 'Tomato', quantity: 0.07 },
      { name: 'Cheese', quantity: 0.02 },
    ],
  },
  {
    name: 'Chicken',
    recipe: [
      { name: 'Chicken', quantity: 0.20 },
      { name: 'Fried chicken batter', quantity: 0.06 },
      { name: 'Cooking oil', quantity: 0.05 },
      { name: 'Spices', quantity: 0.01 },
    ],
  },
  {
    name: 'Spaghetti',
    recipe: [
      { name: 'Pasta', quantity: 0.20 },
      { name: 'Tomato sauce', quantity: 0.10 },
      { name: 'Ground beef', quantity: 0.11 },
      { name: 'Cheese', quantity: 0.02 },
    ],
  },
];

const inventoryIngredients = [];
let foodUseRecords = [];
const inventoryIngredientUnits = new Map([
  ['chicken', 'kg'], ['beef patty', 'kg'], ['burger buns', 'pcs'], ['cooking oil', 'L'],
  ['lettuce', 'kg'], ['tomato', 'kg'], ['cheese', 'kg'], ['flour', 'kg'],
  ['fried chicken batter', 'kg'], ['spices', 'kg'], ['pasta', 'kg'],
  ['tomato sauce', 'L'], ['ground beef', 'kg'],
]);

function getIngredientAliases() {
  try {
    return JSON.parse(localStorage.getItem('wasteWiseIngredientAliases') || '{}');
  } catch {
    return {};
  }
}

function getCurrentIngredientName(name) {
  return getIngredientAliases()[name] || name;
}

function saveIngredientAlias(previousName, nextName) {
  const aliases = getIngredientAliases();
  Object.entries(aliases).forEach(([recipeName, currentName]) => {
    if (currentName.trim().toLocaleLowerCase() === previousName.trim().toLocaleLowerCase()) {
      aliases[recipeName] = nextName;
    }
  });
  aliases[previousName] = nextName;
  localStorage.setItem('wasteWiseIngredientAliases', JSON.stringify(aliases));
}

async function loadInventoryFromAPI() {
  if (!inventoryStockRows && !document.querySelector('#disposal-ingredient-rows')) return;
  try {
    const [ingredients, foods] = await Promise.all([
      requestAPI('/ingredients'),
      requestAPI('/food-items'),
    ]);
    if (foods.length) inventoryFoods = foods;
    inventoryIngredients.length = 0;
    ingredients.forEach((ingredient) => inventoryIngredients.push({
      id: ingredient.id,
      name: ingredient.name,
      unit: inventoryIngredientUnits.get(ingredient.name.trim().toLocaleLowerCase()) || 'kg',
      quantity: Number(ingredient.quantity),
      expiresAt: ingredient.expires_at,
      minimum: 0,
    }));
    renderInventory();
    renderDisposal();
    await loadFoodUseRecords();
  } catch (error) {
    if (inventoryStockRows) inventoryStockRows.innerHTML = `<tr><td colspan="6" class="table-message">${error.message}</td></tr>`;
    if (disposalIngredientRows) disposalIngredientRows.innerHTML = `<tr><td colspan="5" class="table-message">${error.message}</td></tr>`;
  }
}

function getRestockTimes() {
  try {
    return JSON.parse(localStorage.getItem('wasteWiseRestockTimes') || '{}');
  } catch {
    return {};
  }
}

function saveRestockTimes(times) {
  localStorage.setItem('wasteWiseRestockTimes', JSON.stringify(times));
}

function getFoodUseRecords() {
  return foodUseRecords;
}

async function loadFoodUseRecords() {
  const legacyRecords = localStorage.getItem('wasteWiseFoodUseRecords');
  if (legacyRecords !== null) {
    try {
      const records = JSON.parse(legacyRecords);
      if (Array.isArray(records) && records.length) {
        await requestAPI('/food-use-records/import', {
          method: 'POST',
          body: JSON.stringify({ records }),
        });
      }
      localStorage.removeItem('wasteWiseFoodUseRecords');
    } catch (error) {
      console.error('Could not migrate saved food-use history.', error);
    }
  }

  try {
    foodUseRecords = await requestAPI('/food-use-records');
    renderFoodUseRecords();
  } catch (error) {
    if (inventoryFoodRows) inventoryFoodRows.innerHTML = `<tr><td colspan="8" class="table-message">${escapeHTML(error.message)}</td></tr>`;
  }
}

function renderFoodUseRecords() {
  if (!inventoryFoodRows) return;
  const records = getFoodUseRecords().slice().reverse();
  if (records.length === 0) {
    inventoryFoodRows.innerHTML = '<tr><td colspan="8" class="table-message">No food use recorded yet.</td></tr>';
    return;
  }
  inventoryFoodRows.innerHTML = records.map((record, displayIndex) => {
    const storedIndex = records.length - 1 - displayIndex;
    const usedAt = new Date(record.usedAt);
    const expiresAt = new Date(usedAt.getTime() + (24 * 60 * 60 * 1000));
    const isExpired = expiresAt <= new Date();
    const food = inventoryFoods.find((item) => item.name === record.food);
    const ingredientsUsed = record.ingredientsUsed?.length ? record.ingredientsUsed : food?.recipe.map((ingredient) => ({
      ...ingredient,
      quantity: Math.round(ingredient.quantity * Number(record.portions) * 100) / 100,
      unit: inventoryIngredients.find((item) => item.name.trim().toLocaleLowerCase() === getCurrentIngredientName(ingredient.name).trim().toLocaleLowerCase())?.unit || 'kg',
    }));
    const ingredientsList = ingredientsUsed?.length
      ? `<div class="food-use-ingredients-cell">${ingredientsUsed.map((ingredient) => {
        const displayName = getCurrentIngredientName(ingredient.name);
        const stock = inventoryIngredients.find((item) => item.name.trim().toLocaleLowerCase() === displayName.trim().toLocaleLowerCase());
        const available = stock ? `${Number(stock.quantity).toLocaleString('en', { maximumFractionDigits: 2 })} ${stock.unit}` : 'Unknown';
        return `<span>${displayName}: ${Number(ingredient.quantity).toLocaleString('en', { maximumFractionDigits: 2 })} ${ingredient.unit} <small>(Available: ${available})</small></span>`;
      }).join('')}</div>`
      : 'Recipe unavailable';
    return `<tr><td><strong>${escapeHTML(record.food)}</strong></td><td>${record.portions}</td><td>${formatDateTime(usedAt)}</td><td>24 hours</td><td>${formatDateTime(expiresAt)}</td><td>${ingredientsList}</td><td><span class="disposal-status ${isExpired ? 'dispose-now' : 'safe'}">${isExpired ? 'Expired' : 'Fresh'}</span></td><td class="inventory-action-cell"><button class="table-action" type="button" data-delete-food-use="${record.id}" aria-label="Remove ${escapeHTML(record.food)} food-use record" title="Remove record"><i class="bi bi-trash3"></i></button></td></tr>`;
  }).join('');
}

if (inventoryFoodRows) {
  inventoryFoodRows.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-delete-food-use]');
    if (!button) return;
    if (!window.confirm('Remove this food-use record? Deducted ingredient stock will not be restored.')) return;
    const id = Number(button.dataset.deleteFoodUse);
    if (!Number.isInteger(id) || id < 1) return;
    try {
      await requestAPI(`/food-use-records/${id}`, { method: 'DELETE' });
      foodUseRecords = foodUseRecords.filter((record) => record.id !== id);
      renderFoodUseRecords();
    } catch (error) {
      window.alert(error.message);
    }
  });
}

function getFoodRecipeUsage(food, portions) {
  return food.recipe.map((recipeItem) => {
    const currentName = getCurrentIngredientName(recipeItem.name);
    const ingredient = inventoryIngredients.find((item) => item.name.trim().toLocaleLowerCase() === currentName.trim().toLocaleLowerCase());
    return {
      id: ingredient?.id,
      name: recipeItem.name,
      quantity: Math.round(recipeItem.quantity * portions * 100) / 100,
      unit: ingredient?.unit || 'kg',
      available: ingredient?.quantity,
    };
  });
}

function getMaxAvailablePortions(food) {
  const recipeUsage = getFoodRecipeUsage(food, 1);
  if (recipeUsage.some((item) => !Number.isInteger(Number(item.id)) || !Number.isFinite(item.available))) return null;
  return Math.max(0, Math.min(...recipeUsage.map((item) => Math.floor((item.available + 0.000001) / food.recipe.find((recipeItem) => recipeItem.name === item.name).quantity))));
}

function formatRestockTime(value) {
  if (!value) return '';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : `Restocked ${new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date)}`;
}

function getShelfLifeStatus(expiresAt, quantity = 1, now = new Date()) {
  if (Number(quantity) <= 0) {
    return { status: 'No stock', statusClass: 'no-stock', expires: null };
  }
  if (!expiresAt) {
    return { status: 'No expiry set', statusClass: 'no-expiry', expires: null };
  }

  const expires = new Date(expiresAt);
  if (Number.isNaN(expires.getTime())) {
    return { status: 'Invalid expiry date', statusClass: 'invalid-expiry', expires: null };
  }

  const hoursRemaining = (expires - now) / 3600000;
  if (hoursRemaining <= 0) {
    return { status: 'Dispose now', statusClass: 'dispose-now', expires };
  }
  if (hoursRemaining <= 24) {
    return { status: 'Expiring soon', statusClass: 'expiring', expires };
  }
  return { status: 'Safe', statusClass: 'safe', expires };
}

function renderInventory() {
  if (!inventoryStockRows) return;
  const restockTimes = getRestockTimes();
  inventoryStockRows.innerHTML = inventoryIngredients.map((ingredient) => {
    const usedIn = inventoryFoods.filter((food) => food.recipe.some((recipeItem) => getCurrentIngredientName(recipeItem.name).trim().toLocaleLowerCase() === ingredient.name.trim().toLocaleLowerCase())).length;
    const shelfLife = getShelfLifeStatus(ingredient.expiresAt, ingredient.quantity);
    const restockLabel = formatRestockTime(restockTimes[ingredient.name]);
    const expiryLabel = shelfLife.expires ? formatDateTime(shelfLife.expires) : 'Not set';
    return `<tr><td><strong>${ingredient.name}</strong>${restockLabel ? `<small class="restock-time">${restockLabel}</small>` : ''}</td><td>${usedIn} food${usedIn === 1 ? '' : 's'}</td><td>${ingredient.quantity} ${ingredient.unit}</td><td>${expiryLabel}</td><td><span class="disposal-status ${shelfLife.statusClass}">${shelfLife.status}</span></td><td class="inventory-action-cell"><button class="table-action inventory-restock-action" type="button" data-restock-ingredient="${ingredient.name}" aria-label="Edit stock and shelf-life status for ${ingredient.name}" title="Edit stock and shelf-life status"><i class="bi bi-pencil-square"></i></button></td></tr>`;
  }).join('');
  renderFoodUseRecords();
  const totalStock = inventoryIngredients.reduce((total, ingredient) => total + (ingredient.unit === 'kg' ? ingredient.quantity : 0), 0);
  document.querySelector('#inventory-total-stock').innerHTML = `${totalStock} <small>kg</small>`;
  document.querySelector('#inventory-ingredient-count').textContent = inventoryIngredients.length;
  document.querySelector('#inventory-restock-count').textContent = inventoryIngredients.filter((ingredient) => ingredient.quantity < ingredient.minimum).length;
}

renderInventory();
loadInventoryFromAPI();

const inventoryEditDialog = document.querySelector('#inventory-edit-dialog');
const inventoryEditForm = document.querySelector('#inventory-edit-form');
const inventoryEditIngredientName = document.querySelector('#inventory-ingredient-name');
const inventoryRemoveButton = document.querySelector('#inventory-remove-button');
const inventoryEditFeedback = document.querySelector('#inventory-edit-feedback');
const inventoryRestockTime = document.querySelector('#inventory-restock-time');
const inventoryStockQuantity = document.querySelector('#inventory-stock-quantity');
const inventoryExpiresAt = document.querySelector('#inventory-expires-at');
const inventoryEditUnit = document.querySelector('#inventory-edit-unit');
const inventoryEditStatus = document.querySelector('#inventory-edit-status');
let editingIngredientName = '';
let editingRestockTimeValue = '';

function toDateTimeInputValue(value) {
  const date = value ? new Date(value) : new Date();
  const pad = (number) => String(number).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function updateInventoryEditStatus() {
  const ingredient = inventoryIngredients.find((item) => item.name === editingIngredientName);
  const quantity = Number(inventoryStockQuantity.value);
  if (!ingredient || !Number.isFinite(quantity)) return;
  const shelfLife = getShelfLifeStatus(inventoryExpiresAt.value, quantity);
  inventoryEditStatus.textContent = shelfLife.status;
  inventoryEditStatus.className = shelfLife.statusClass;
}

if (inventoryStockRows && inventoryEditDialog && inventoryEditForm) {
  inventoryStockRows.addEventListener('click', (event) => {
    const button = event.target.closest('[data-restock-ingredient]');
    if (!button) return;
    const ingredientName = button.dataset.restockIngredient;
    const ingredient = inventoryIngredients.find((item) => item.name === ingredientName);
    if (!ingredient) return;
    editingIngredientName = ingredientName;
    inventoryEditIngredientName.value = ingredient.name;
    inventoryEditUnit.textContent = ingredient.unit;
    inventoryStockQuantity.value = ingredient.quantity;
    inventoryRestockTime.value = toDateTimeInputValue(getRestockTimes()[ingredientName]);
    inventoryExpiresAt.value = ingredient.expiresAt ? toDateTimeInputValue(ingredient.expiresAt) : '';
    editingRestockTimeValue = inventoryRestockTime.value;
    inventoryEditFeedback.textContent = '';
    inventoryRemoveButton.disabled = !Number.isInteger(Number(ingredient.id)) || Number(ingredient.id) < 1;
    updateInventoryEditStatus();
    inventoryEditDialog.showModal();
  });

  inventoryRemoveButton.addEventListener('click', async () => {
    const ingredientIndex = inventoryIngredients.findIndex((item) => item.name === editingIngredientName);
    const ingredient = inventoryIngredients[ingredientIndex];
    if (!ingredient || !window.confirm(`Remove ${ingredient.name} from inventory?`)) return;
    inventoryRemoveButton.disabled = true;
    inventoryEditFeedback.textContent = '';
    try {
      await requestAPI(`/ingredients/${ingredient.id}`, { method: 'DELETE' });
      inventoryIngredients.splice(ingredientIndex, 1);
      const restockTimes = getRestockTimes();
      delete restockTimes[ingredient.name];
      saveRestockTimes(restockTimes);
      renderInventory();
      inventoryEditDialog.close();
    } catch (error) {
      inventoryEditFeedback.textContent = `${error.message} Restart the server if the delete route was just added.`;
      inventoryRemoveButton.disabled = false;
    }
  });

  inventoryStockQuantity.addEventListener('input', updateInventoryEditStatus);
  inventoryExpiresAt.addEventListener('input', updateInventoryEditStatus);
  inventoryExpiresAt.addEventListener('change', updateInventoryEditStatus);
  inventoryEditForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const ingredient = inventoryIngredients.find((item) => item.name === editingIngredientName);
    const originalName = editingIngredientName;
    const name = inventoryEditIngredientName.value.trim();
    const quantity = Number(inventoryStockQuantity.value);
    const expiresAt = new Date(inventoryExpiresAt.value);
    const restockDate = new Date(inventoryRestockTime.value);
    if (!ingredient || !name || name.length > 100 || !Number.isFinite(quantity) || quantity < 0 || Number.isNaN(restockDate.getTime()) || Number.isNaN(expiresAt.getTime())) return;
    if (inventoryIngredients.some((item) => item.id !== ingredient.id && item.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
      inventoryEditFeedback.textContent = 'An ingredient with that name already exists.';
      return;
    }
    const quantityChanged = quantity !== Number(ingredient.quantity);
    const restockDateChanged = inventoryRestockTime.value !== editingRestockTimeValue;
    const saveButton = inventoryEditForm.querySelector('button[type="submit"]');
    saveButton.disabled = true;
    inventoryEditFeedback.textContent = '';
    try {
      const updatedIngredient = await requestAPI(`/ingredients/${ingredient.id}`, {
        method: 'PUT',
        body: JSON.stringify({ name, quantity, expiresAt: expiresAt.toISOString() }),
      });
      const restockTimes = getRestockTimes();
      const previousRestockTime = restockTimes[originalName];
      if (originalName !== name) {
        delete restockTimes[originalName];
        if (previousRestockTime) restockTimes[name] = previousRestockTime;
        saveIngredientAlias(originalName, name);
      }
      if (quantityChanged || restockDateChanged) restockTimes[name] = restockDate.toISOString();
      saveRestockTimes(restockTimes);
      ingredient.name = updatedIngredient.name;
      ingredient.quantity = Number(updatedIngredient.quantity);
      ingredient.expiresAt = updatedIngredient.expires_at;
      editingIngredientName = updatedIngredient.name;
      renderInventory();
      inventoryEditDialog.close();
    } catch (error) {
      inventoryEditFeedback.textContent = error.message;
    } finally {
      saveButton.disabled = false;
    }
  });

  document.querySelectorAll('#inventory-edit-cancel, #inventory-edit-cancel-button').forEach((button) => {
    button.addEventListener('click', () => inventoryEditDialog.close());
  });
}

const inventoryAddButton = document.querySelector('#add-ingredient-button');
const inventoryAddDialog = document.querySelector('#inventory-add-dialog');
const inventoryAddForm = document.querySelector('#inventory-add-form');

if (inventoryAddButton && inventoryAddDialog && inventoryAddForm) {
  inventoryAddButton.addEventListener('click', () => {
    inventoryAddForm.reset();
    inventoryAddDialog.showModal();
  });

  inventoryAddForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const formData = new FormData(inventoryAddForm);
    const name = String(formData.get('name')).trim();
    const unit = 'kg';
    const quantity = Number(formData.get('quantity'));
    const expiresAt = new Date(String(formData.get('expiresAt')));
    const minimum = 0;
    if (!name || !Number.isFinite(quantity) || quantity < 0 || Number.isNaN(expiresAt.getTime())) return;
    if (inventoryIngredients.some((ingredient) => ingredient.name.toLowerCase() === name.toLowerCase())) {
      inventoryAddForm.elements.name.setCustomValidity('This ingredient already exists.');
      inventoryAddForm.elements.name.reportValidity();
      return;
    }
    inventoryAddForm.elements.name.setCustomValidity('');
    const submitButton = inventoryAddForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    try {
      const addedIngredient = await requestAPI('/ingredients', {
        method: 'POST',
        body: JSON.stringify({
          quantity,
          name,
          expiresAt: expiresAt.toISOString(),
        }),
      });
      inventoryIngredients.push({
        id: addedIngredient.id,
        name: addedIngredient.name,
        unit: addedIngredient.unit,
        quantity: Number(addedIngredient.quantity),
        expiresAt: addedIngredient.expires_at,
        minimum: Number(addedIngredient.minimum_quantity),
      });
      renderInventory();
      inventoryAddDialog.close();
    } catch (error) {
      window.alert(error.message || 'Could not connect to the database.');
    } finally {
      submitButton.disabled = false;
    }
  });

  document.querySelectorAll('#inventory-add-cancel, #inventory-add-cancel-button').forEach((button) => {
    button.addEventListener('click', () => inventoryAddDialog.close());
  });
}

const foodUseButton = document.querySelector('#record-food-use-button');
const foodUseDialog = document.querySelector('#food-use-dialog');
const foodUseForm = document.querySelector('#food-use-form');

if (foodUseButton && foodUseDialog && foodUseForm) {
  const foodSelect = foodUseForm.elements.food;
  const portionsInput = foodUseForm.elements.portions;
  const usedAtInput = foodUseForm.elements.usedAt;
  const recipeList = document.querySelector('#food-use-ingredients');
  const recipeFeedback = document.querySelector('#food-use-feedback');
  const portionsAvailability = document.querySelector('#food-use-max-portions');
  const saveFoodUseButton = foodUseForm.querySelector('button[type="submit"]');

  const renderSelectedFoodRecipe = () => {
    const food = inventoryFoods.find((item) => item.name === foodSelect.value);
    const portions = Number(portionsInput.value);
    const maxPortions = food ? getMaxAvailablePortions(food) : null;
    portionsAvailability.textContent = maxPortions === null
      ? 'Maximum portions: unavailable until ingredient stock loads.'
      : `Maximum portions available: ${maxPortions}`;
    if (!food || !Number.isInteger(portions) || portions < 1) {
      recipeList.innerHTML = '';
      recipeFeedback.textContent = 'Enter the number of portions to see the ingredients required.';
      saveFoodUseButton.disabled = true;
      return;
    }

    const recipeUsage = getFoodRecipeUsage(food, portions);
    const missingIngredients = recipeUsage.filter((item) => !Number.isInteger(Number(item.id)));
    const insufficientIngredients = recipeUsage.filter((item) => (
      Number.isFinite(item.available) && item.available + 0.000001 < item.quantity
    ));
    recipeList.innerHTML = recipeUsage.map((item) => (
      `<li><span>${item.name}</span><strong>${item.quantity.toFixed(2)} ${item.unit}</strong></li>`
    )).join('');

    if (missingIngredients.length) {
      recipeFeedback.textContent = 'Ingredient stock is unavailable. Check the database connection and try again.';
      recipeFeedback.className = 'food-use-feedback error';
      saveFoodUseButton.disabled = true;
    } else if (insufficientIngredients.length) {
      recipeFeedback.textContent = `Not enough stock: ${insufficientIngredients.map((item) => item.name).join(', ')}.`;
      recipeFeedback.className = 'food-use-feedback error';
      saveFoodUseButton.disabled = true;
    } else if (maxPortions !== null && portions > maxPortions) {
      recipeFeedback.textContent = `Reduce portions to ${maxPortions} or fewer.`;
      recipeFeedback.className = 'food-use-feedback error';
      saveFoodUseButton.disabled = true;
    } else {
      recipeFeedback.textContent = 'These amounts will be deducted from ingredient stock.';
      recipeFeedback.className = 'food-use-feedback';
      saveFoodUseButton.disabled = false;
    }
  };

  foodUseButton.addEventListener('click', () => {
    foodSelect.innerHTML = inventoryFoods.map((food) => `<option value="${food.name}">${food.name}</option>`).join('');
    foodUseForm.reset();
    const selectedFood = inventoryFoods.find((food) => food.name === foodSelect.value);
    portionsInput.value = String(selectedFood ? getMaxAvailablePortions(selectedFood) ?? 1 : 1);
    usedAtInput.value = toDateTimeInputValue();
    renderSelectedFoodRecipe();
    foodUseDialog.showModal();
  });

  foodSelect.addEventListener('change', () => {
    const selectedFood = inventoryFoods.find((food) => food.name === foodSelect.value);
    portionsInput.value = String(selectedFood ? getMaxAvailablePortions(selectedFood) ?? 1 : 1);
    renderSelectedFoodRecipe();
  });
  portionsInput.addEventListener('input', renderSelectedFoodRecipe);
  foodUseForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const food = String(foodSelect.value);
    const portions = Number(foodUseForm.elements.portions.value);
    const usedAt = new Date(usedAtInput.value);
    if (!inventoryFoods.some((item) => item.name === food) || !Number.isInteger(portions) || portions < 1 || Number.isNaN(usedAt.getTime())) return;

    const recipeUsage = getFoodRecipeUsage(inventoryFoods.find((item) => item.name === food), portions);
    if (recipeUsage.some((item) => !Number.isInteger(Number(item.id)) || item.available < item.quantity)) {
      renderSelectedFoodRecipe();
      return;
    }

    saveFoodUseButton.disabled = true;
    try {
      const result = await requestAPI('/food-use-records', {
        method: 'POST',
        body: JSON.stringify({ food, portions, usedAt: usedAt.toISOString() }),
      });
      foodUseRecords.push(result);
      const updatedIngredients = await requestAPI('/ingredients');
      updatedIngredients.forEach((updatedIngredient) => {
        const ingredient = inventoryIngredients.find((item) => item.id === updatedIngredient.id);
        if (ingredient) ingredient.quantity = Number(updatedIngredient.quantity);
      });
      renderInventory();
      foodUseDialog.close();
    } catch (error) {
      window.alert(error.message);
      renderSelectedFoodRecipe();
    } finally {
      if (foodUseDialog.open) renderSelectedFoodRecipe();
    }
  });

  document.querySelectorAll('#food-use-cancel, #food-use-cancel-button').forEach((button) => {
    button.addEventListener('click', () => foodUseDialog.close());
  });
}

const disposalFoodRows = document.querySelector('#disposal-food-rows');
const disposalIngredientRows = document.querySelector('#disposal-ingredient-rows');
const disposeSelectedButton = document.querySelector('#dispose-selected-button');
function formatShortDate(date) {
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(date);
}

function formatDateTime(date) {
  return new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
}

function getDisposalState() {
  try {
    return JSON.parse(localStorage.getItem('wasteWiseDisposalState') || '{"removed":[],"checked":[]}');
  } catch {
    return { removed: [], checked: [] };
  }
}

function saveDisposalState(state) {
  localStorage.setItem('wasteWiseDisposalState', JSON.stringify(state));
}

function renderDisposal() {
  if (!disposalFoodRows && !disposalIngredientRows) return;
  const now = new Date();
  const disposalState = getDisposalState();
  const recordedFoodUses = getFoodUseRecords().map((record, index) => ({
    key: record.id || `use:${index}`,
    isRecorded: true,
    name: record.food,
    quantity: record.portions,
    prepared: new Date(record.usedAt),
    shelfLifeHours: 24,
    ingredients: (record.ingredientsUsed || []).map((ingredient) => [
      ingredient.name,
      `${ingredient.quantity} ${ingredient.unit}`,
    ]),
  }));
  const allFoodRecords = recordedFoodUses;
  const records = allFoodRecords.filter((record) => (
    !disposalState.removed.includes(record.key)
  )).map((record) => {
    const prepared = record.prepared || (() => {
      const date = new Date(now);
      date.setHours(record.preparedHour, 0, 0, 0);
      date.setDate(date.getDate() - record.preparedDaysAgo);
      return date;
    })();
    const expires = new Date(prepared.getTime() + (record.shelfLifeHours * 3600000));
    const shelfLife = getShelfLifeStatus(expires, record.quantity, now);
    return { ...record, prepared, expires, ...shelfLife };
  });
  const ingredientShelfLife = inventoryIngredients.map((ingredient) => {
    return { ...ingredient, ...getShelfLifeStatus(ingredient.expiresAt, ingredient.quantity, now) };
  }).filter((ingredient) => ingredient.quantity > 0 && ingredient.expires && !Number.isNaN(ingredient.expires.getTime()));
  const expiredItems = ingredientShelfLife.filter((ingredient) => ingredient.status === 'Dispose now').length;
  const expiringItems = ingredientShelfLife.filter((ingredient) => ingredient.status === 'Expiring soon').length;
  document.querySelector('#disposal-total-items').textContent = expiredItems;
  document.querySelector('#disposal-expiring-items').textContent = expiringItems;
  document.querySelector('#disposal-safe-items').textContent = ingredientShelfLife.filter((ingredient) => ingredient.status === 'Safe').length;
  const disposalDateLabel = document.querySelector('#disposal-date-label');
  if (disposalDateLabel) disposalDateLabel.textContent = `Checked ${formatShortDate(now)}`;
  if (disposalFoodRows) {
    disposalFoodRows.innerHTML = records.map((record, index) => {
    const statusClass = record.status === 'Dispose now' ? 'dispose-now' : record.status === 'Expiring soon' ? 'expiring' : 'safe';
    const ingredientAction = record.status === 'Dispose now' ? 'Dispose' : record.status === 'Expiring soon' ? 'Prioritize' : 'Keep';
    const ingredientClass = record.status === 'Dispose now' ? 'dispose-now' : record.status === 'Expiring soon' ? 'expiring' : 'safe';
    const ingredientRows = record.ingredients.map(([name, amount], ingredientIndex) => {
      const ingredientKey = `${record.key}:${ingredientIndex}`;
      const isChecked = disposalState.checked.includes(ingredientKey);
      return `<tr><td><label class="disposal-checkbox"><input type="checkbox" data-disposal-ingredient="${ingredientKey}" ${isChecked ? 'checked' : ''}><span>${name}</span></label></td><td>${amount}</td><td><span class="disposal-status ${ingredientClass}">${isChecked ? 'Disposed' : ingredientAction}</span></td></tr>`;
    }).join('');
    const colspan = 7;
    return `<tr class="disposal-food-row"><td><button class="disposal-food-toggle" type="button" data-disposal-index="${index}" aria-expanded="false"><i class="bi bi-chevron-right"></i><strong>${record.name}</strong></button></td><td>${record.quantity} portions</td><td>${formatDateTime(record.prepared)}</td><td>${record.shelfLifeHours} hours</td><td>${formatDateTime(record.expires)}</td><td><span class="disposal-status ${statusClass}">${record.status}</span></td><td><label class="dispose-food-checkbox"><input type="checkbox" data-select-disposal="${record.key}" aria-label="Select ${record.name} batch for disposal"><span>Dispose</span></label></td></tr><tr class="disposal-ingredients-row" data-disposal-details="${index}" hidden><td colspan="${colspan}"><div class="disposal-ingredients"><strong>Ingredients in ${record.name}</strong><table><thead><tr><th>Ingredient</th><th>Amount</th><th>Action</th></tr></thead><tbody>${ingredientRows}</tbody></table></div></td></tr>`;
    }).join('');
    disposalFoodRows.querySelectorAll('[data-disposal-index]').forEach((button) => {
      button.addEventListener('click', () => {
        const details = disposalFoodRows.querySelector(`[data-disposal-details="${button.dataset.disposalIndex}"]`);
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!isExpanded));
        button.querySelector('i').classList.toggle('bi-chevron-right', isExpanded);
        button.querySelector('i').classList.toggle('bi-chevron-down', !isExpanded);
        details.hidden = isExpanded;
      });
    });
  }
  if (disposalIngredientRows) {
    const expiringIngredients = inventoryIngredients.map((ingredient) => ({
      ...ingredient,
      ...getShelfLifeStatus(ingredient.expiresAt, ingredient.quantity, now),
    })).filter((ingredient) => ingredient.quantity > 0 && ingredient.expires && ingredient.status !== 'Safe');
    disposalIngredientRows.innerHTML = expiringIngredients.length
      ? expiringIngredients.map((ingredient) => {
        return `<tr><td><strong>${ingredient.name}</strong></td><td>${ingredient.quantity} ${ingredient.unit}</td><td>${formatDateTime(ingredient.expires)}</td><td><span class="disposal-status ${ingredient.statusClass}">${ingredient.status}</span></td><td class="inventory-action-cell"><button class="table-action" type="button" data-dispose-ingredient="${ingredient.id}" aria-label="Dispose all ${ingredient.quantity} ${ingredient.unit} of ${ingredient.name}" title="Dispose all stock"><i class="bi bi-trash3"></i></button></td></tr>`;
      }).join('')
      : '<tr><td colspan="5" class="table-message">No ingredients are expired or expiring within 24 hours.</td></tr>';
    disposalIngredientRows.onclick = async (event) => {
      const button = event.target.closest('[data-dispose-ingredient]');
      if (!button) return;
      const ingredient = inventoryIngredients.find((item) => item.id === Number(button.dataset.disposeIngredient));
      if (!ingredient || !window.confirm(`Dispose all ${ingredient.quantity} ${ingredient.unit} of ${ingredient.name}?`)) return;
      button.disabled = true;
      try {
        const result = await requestAPI(`/ingredients/${ingredient.id}/dispose`, {
          method: 'POST',
          body: JSON.stringify({ quantity: ingredient.quantity, unit: ingredient.unit }),
        });
        ingredient.quantity = Number(result.quantity);
        renderInventory();
        renderDisposal();
        if (inventoryStockRows || disposalIngredientRows || disposalFoodRows) {
          window.setInterval(() => {
            renderInventory();
            renderDisposal();
            updateInventoryEditStatus();
          }, 60_000);
        }
      } catch (error) {
        window.alert(error.message);
        button.disabled = false;
      }
    };
  }
  if (disposalFoodRows) {
    disposalFoodRows.querySelectorAll('[data-disposal-ingredient]').forEach((checkbox) => {
      checkbox.addEventListener('change', () => {
        const state = getDisposalState();
        const ingredientKey = checkbox.dataset.disposalIngredient;
        state.checked = checkbox.checked ? [...new Set([...state.checked, ingredientKey])] : state.checked.filter((key) => key !== ingredientKey);
        saveDisposalState(state);
        renderDisposal();
      });
    });
    if (disposeSelectedButton) {
      disposeSelectedButton.onclick = async () => {
        const selectedFoods = [...disposalFoodRows.querySelectorAll('[data-select-disposal]:checked')].map((checkbox) => checkbox.dataset.selectDisposal);
        if (!selectedFoods.length) return;
        const removedRecords = records.filter((record) => selectedFoods.includes(record.key));
        disposeSelectedButton.disabled = true;
        try {
          await requestAPI('/disposals', {
            method: 'POST',
            body: JSON.stringify({
              items: removedRecords.map((record) => ({
                itemType: 'food',
                itemName: record.name,
                quantity: record.quantity,
                unit: 'portions',
              })),
            }),
          });
        } catch (error) {
          window.alert(error.message);
          disposeSelectedButton.disabled = false;
          return;
        }
        const state = getDisposalState();
        state.removed = [...new Set([...state.removed, ...selectedFoods])];
        state.checked = state.checked.filter((key) => (
          !removedRecords.some((record) => key.startsWith(`${record.key}:`))
        ));
        saveDisposalState(state);
        renderDisposal();
        disposeSelectedButton.disabled = false;
      };
    }
  }
}

renderDisposal();

const regressionChart = document.querySelector('#regression-chart');
const reportWasteRows = document.querySelector('#report-waste-rows');

function trainSimpleRegression(logs) {
  const xValues = logs.map((log) => Number(log.mealsServed));
  const yValues = logs.map((log) => Number(log.wasteKg));
  const xAverage = xValues.reduce((sum, value) => sum + value, 0) / xValues.length;
  const yAverage = yValues.reduce((sum, value) => sum + value, 0) / yValues.length;
  const covariance = xValues.reduce((sum, value, index) => sum + ((value - xAverage) * (yValues[index] - yAverage)), 0);
  const variance = xValues.reduce((sum, value) => sum + ((value - xAverage) ** 2), 0);
  const slope = variance ? covariance / variance : 0;
  const intercept = yAverage - (slope * xAverage);
  const totalVariance = yValues.reduce((sum, value) => sum + ((value - yAverage) ** 2), 0);
  const residualVariance = yValues.reduce((sum, value, index) => sum + ((value - (intercept + (slope * xValues[index]))) ** 2), 0);
  return { slope, intercept, rSquared: totalVariance ? Math.max(0, 1 - (residualVariance / totalVariance)) : 0 };
}

function renderRegressionChart(logs, model) {
  if (!regressionChart) return;
  const width = 760;
  const height = 300;
  const padding = { top: 20, right: 18, bottom: 35, left: 48 };
  const actualValues = logs.map((log) => Number(log.wasteKg));
  const lastLog = logs[logs.length - 1];
  const mealStep = logs.length > 1 ? Number(logs[logs.length - 1].mealsServed) - Number(logs[logs.length - 2].mealsServed) : 20;
  const dateStep = 86400000;
  const forecastLogs = Array.from({ length: 2 }, (_, index) => {
    const date = new Date(`${lastLog.date}T00:00:00`);
    date.setTime(date.getTime() + (dateStep * (index + 1)));
    const mealsServed = Number(lastLog.mealsServed) + (mealStep * (index + 1));
    return { date: date.toISOString().slice(0, 10), mealsServed, wasteKg: Math.max(0, model.intercept + (model.slope * mealsServed)) };
  });
  const allValues = [...actualValues, ...forecastLogs.map((log) => log.wasteKg)];
  const yMax = Math.max(20, Math.ceil(Math.max(...allValues, 0) / 5) * 5);
  const plotX = (index) => padding.left + ((index / (logs.length + 1)) * (width - padding.left - padding.right));
  const plotY = (value) => height - padding.bottom - ((value / yMax) * (height - padding.top - padding.bottom));
  const baseline = height - padding.bottom;
  const actualPoints = logs.map((log, index) => [plotX(index), plotY(Number(log.wasteKg))]);
  const forecastPoints = [[plotX(logs.length - 1), plotY(Number(lastLog.wasteKg))], ...forecastLogs.map((log, index) => [plotX(logs.length + index), plotY(log.wasteKg)])];
  const toPath = (points) => points.map(([x, y], index) => `${index ? 'L' : 'M'} ${x} ${y}`).join(' ');
  const toAreaPath = (points) => `${toPath(points)} L ${points[points.length - 1][0]} ${baseline} L ${points[0][0]} ${baseline} Z`;
  const grid = Array.from({ length: 5 }, (_, index) => {
    const value = (yMax / 4) * index;
    const y = plotY(value);
    return `<line class="regression-grid-line" x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}"></line><text class="regression-axis-text" x="${padding.left - 8}" y="${y + 3}" text-anchor="end">${value.toFixed(0)}</text>`;
  }).join('');
  const points = logs.map((log, index) => `<circle class="regression-point actual-point" cx="${actualPoints[index][0]}" cy="${actualPoints[index][1]}" r="5"><title>${formatDate(log.date)}: ${Number(log.wasteKg).toFixed(2)} kg</title></circle>`).join('');
  const forecastCircles = forecastLogs.map((log, index) => `<circle class="regression-point forecast-point" cx="${forecastPoints[index + 1][0]}" cy="${forecastPoints[index + 1][1]}" r="5"><title>${formatDate(log.date)} forecast: ${Number(log.wasteKg).toFixed(2)} kg</title></circle>`).join('');
  const labels = [...logs, ...forecastLogs].map((log, index) => `<text class="regression-axis-text regression-date" x="${plotX(index)}" y="${height - 10}" text-anchor="middle">${new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date(`${log.date}T00:00:00`))}</text>`).join('');
  regressionChart.innerHTML = `${grid}<path class="actual-area" d="${toAreaPath(actualPoints)}"></path><path class="predicted-area" d="${toAreaPath(forecastPoints)}"></path><path class="actual-line" d="${toPath(actualPoints)}"></path><path class="regression-line" d="${toPath(forecastPoints)}"></path>${points}${forecastCircles}${labels}`;
}

function renderWasteReport() {
  if (!regressionChart) return;
  const logs = getWasteLogs();
  if (logs.length === 0) {
    document.querySelector('#report-total-waste').innerHTML = '0.00 <small>kg</small>';
    document.querySelector('#report-average-waste').innerHTML = '0.00 <small>kg</small>';
    document.querySelector('#report-model-fit').textContent = '-';
    document.querySelector('#report-model-equation').textContent = 'Waiting for waste logs';
    regressionChart.replaceChildren();
    return;
  }
  const model = trainSimpleRegression(logs);
  const totalWaste = logs.reduce((sum, log) => sum + Number(log.wasteKg), 0);
  const averageWaste = totalWaste / logs.length;
  const highestWaste = logs.reduce((highest, log) => Number(log.wasteKg) > Number(highest.wasteKg) ? log : highest, logs[0]);
  const trend = model.slope >= 0 ? 'increases' : 'decreases';
  document.querySelector('#report-total-waste').innerHTML = `${totalWaste.toFixed(2)} <small>kg</small>`;
  document.querySelector('#report-average-waste').innerHTML = `${averageWaste.toFixed(2)} <small>kg</small>`;
  document.querySelector('#report-model-fit').textContent = `${Math.round(model.rSquared * 100)}%`;
  document.querySelector('#report-model-equation').textContent = `Waste = ${(model.intercept).toFixed(2)} + ${(model.slope).toFixed(3)} x meals`;
  const reportInsight = document.querySelector('#report-insight');
  if (reportInsight) reportInsight.textContent = `Waste ${trend} by ${Math.abs(model.slope).toFixed(3)} kg for each additional meal served. Highest waste was ${Number(highestWaste.wasteKg).toFixed(2)} kg on ${formatDate(highestWaste.date)}.`;
  if (reportWasteRows) reportWasteRows.innerHTML = logs.slice().reverse().map((log) => `<tr><td>${formatDate(log.date)}</td><td><strong>${Number(log.wasteKg).toFixed(2)} kg</strong></td><td>${Number(log.mealsServed).toLocaleString()}</td><td>${(Number(log.wasteKg) / Number(log.mealsServed)).toFixed(3)} kg</td></tr>`).join('');
  renderRegressionChart(logs, model);
}

renderWasteReport();
renderDisposalRegression();

async function renderDisposalRegression() {
  const rows = document.querySelector('#disposal-regression-rows');
  const count = document.querySelector('#disposal-regression-count');
  if (!rows || !count) return;

  try {
    const records = await requestAPI('/disposals');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const firstDay = new Date(today);
    firstDay.setDate(firstDay.getDate() - 6);
    const weeklyModel = renderDashboardDisposalChart(records, firstDay, today, {
      chart: '#disposal-regression-chart',
      yAxis: '#disposal-regression-y-axis',
      xAxis: '#disposal-regression-x-axis',
    });
    document.querySelector('#report-total-waste').innerHTML = `${weeklyModel.total.toFixed(2)} <small>kg</small>`;
    document.querySelector('#report-average-waste').innerHTML = `${weeklyModel.average.toFixed(2)} <small>kg</small>`;
    document.querySelector('#report-model-fit').textContent = `${Math.round(weeklyModel.rSquared * 100)}%`;
    const groups = new Map();
    records.forEach((record) => {
      const unit = String(record.unit || '').trim();
      const itemType = String(record.item_type || '');
      const quantity = Number(record.quantity);
      const disposedAt = new Date(record.disposed_at);
      if (!unit || !Number.isFinite(quantity) || Number.isNaN(disposedAt.getTime())) return;
      const key = `${itemType}:${unit}`;
      const day = disposedAt.toISOString().slice(0, 10);
      if (!groups.has(key)) groups.set(key, { itemType, unit, dailyTotals: new Map() });
      const dailyTotals = groups.get(key).dailyTotals;
      dailyTotals.set(day, (dailyTotals.get(day) || 0) + quantity);
    });

    const analyses = [...groups.values()].map((group) => {
      const days = [...group.dailyTotals.entries()].sort(([first], [second]) => first.localeCompare(second));
      const xValues = days.map(([day]) => Date.parse(`${day}T00:00:00Z`) / 86400000);
      const yValues = days.map(([, total]) => total);
      const xAverage = xValues.reduce((sum, value) => sum + value, 0) / xValues.length;
      const yAverage = yValues.reduce((sum, value) => sum + value, 0) / yValues.length;
      const variance = xValues.reduce((sum, value) => sum + ((value - xAverage) ** 2), 0);
      const slope = variance
        ? xValues.reduce((sum, value, index) => sum + ((value - xAverage) * (yValues[index] - yAverage)), 0) / variance
        : 0;
      const residualVariance = yValues.reduce((sum, value, index) => sum + ((value - (yAverage + (slope * (xValues[index] - xAverage)))) ** 2), 0);
      const totalVariance = yValues.reduce((sum, value) => sum + ((value - yAverage) ** 2), 0);
      const rSquared = totalVariance ? Math.max(0, 1 - (residualVariance / totalVariance)) : 0;
      return { ...group, dayCount: days.length, slope, rSquared };
    });

    count.textContent = `${records.length} recent disposal${records.length === 1 ? '' : 's'}`;
    const analyzableGroups = analyses.filter((analysis) => analysis.dayCount >= 3);
    rows.innerHTML = analyzableGroups.length
      ? analyzableGroups.map((analysis) => {
        const label = `${analysis.itemType === 'ingredient' ? 'Ingredients' : 'Food'} (${analysis.unit})`;
        const direction = Math.abs(analysis.slope) < 0.01 ? 'Stable' : analysis.slope > 0 ? 'Increasing' : 'Decreasing';
        const signedSlope = analysis.slope > 0 ? '+' : '';
        return `<tr><td><strong>${escapeHTML(label)}</strong></td><td>${analysis.dayCount}</td><td>${signedSlope}${analysis.slope.toFixed(2)} ${escapeHTML(analysis.unit)}</td><td>${Math.round(analysis.rSquared * 100)}%</td><td>${direction}</td></tr>`;
      }).join('')
      : `<tr><td colspan="5" class="table-message">${records.length ? 'At least three disposal days in the same unit are needed for regression.' : 'No disposed items are available for analysis yet.'}</td></tr>`;
  } catch (error) {
    count.textContent = 'Unavailable';
    const chart = document.querySelector('#disposal-regression-chart');
    const yAxis = document.querySelector('#disposal-regression-y-axis');
    const xAxis = document.querySelector('#disposal-regression-x-axis');
    if (chart) chart.innerHTML = `<text class="regression-axis-text" x="310" y="125" text-anchor="middle">${escapeHTML(error.message)}</text>`;
    if (yAxis) yAxis.replaceChildren();
    if (xAxis) xAxis.replaceChildren();
    document.querySelector('#report-model-fit').textContent = '-';
    rows.innerHTML = `<tr><td colspan="5" class="table-message">${escapeHTML(error.message)}</td></tr>`;
  }
}

function getDashboardDateKey(date) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function renderDashboardDisposalChart(records, startDate, endDate, selectors = {}) {
  const chart = document.querySelector(selectors.chart || '#dashboard-disposal-chart');
  const yAxis = document.querySelector(selectors.yAxis || '#dashboard-disposal-y-axis');
  const xAxis = document.querySelector(selectors.xAxis || '#dashboard-disposal-x-axis');
  if (!chart || !yAxis || !xAxis) return;

  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(startDate);
    date.setDate(date.getDate() + index);
    const key = getDashboardDateKey(date);
    const quantity = records.filter((record) => (
      record.item_type === 'ingredient' && String(record.unit).trim().toLocaleLowerCase() === 'kg'
    )).reduce((total, record) => {
      const disposedAt = new Date(record.disposed_at);
      return !Number.isNaN(disposedAt.getTime()) && getDashboardDateKey(disposedAt) === key
        ? total + (Number(record.quantity) || 0)
        : total;
    }, 0);
    return { date, quantity };
  });
  const values = days.map((day) => day.quantity);
  const hasEnoughDays = days.filter((day) => day.quantity > 0).length >= 3;
  const xAverage = (days.length - 1) / 2;
  const yAverage = values.reduce((total, value) => total + value, 0) / days.length;
  const xVariance = days.reduce((total, _, index) => total + ((index - xAverage) ** 2), 0);
  const slope = days.reduce((total, _, index) => total + ((index - xAverage) * (values[index] - yAverage)), 0) / xVariance;
  const intercept = yAverage - (slope * xAverage);
  const residualVariance = values.reduce((total, value, index) => total + ((value - (intercept + (slope * index))) ** 2), 0);
  const totalVariance = values.reduce((total, value) => total + ((value - yAverage) ** 2), 0);
  const rSquared = totalVariance ? Math.max(0, 1 - (residualVariance / totalVariance)) : 0;
  const forecast = hasEnoughDays ? [7, 8].map((index) => Math.max(0, intercept + (slope * index))) : [];
  const maximum = Math.max(5, Math.ceil(Math.max(...values, ...forecast, 0) / 5) * 5);
  const bottom = 225;
  const plotX = (index) => (index / (6 + forecast.length)) * 620;
  const plotY = (value) => bottom - ((value / maximum) * 205);
  const actualPoints = values.map((value, index) => [plotX(index), plotY(value)]);
  const linePath = (points) => points.map(([x, y], index) => `${index ? 'L' : 'M'} ${x} ${y}`).join(' ');
  const actualLine = linePath(actualPoints);
  const actualArea = `${actualLine} L 620 ${bottom} L 0 ${bottom} Z`;
  const forecastPoints = [actualPoints[actualPoints.length - 1], ...forecast.map((value, index) => [plotX(7 + index), plotY(value)])];
  const forecastLine = linePath(forecastPoints);
  const forecastArea = `${forecastLine} L ${forecastPoints[forecastPoints.length - 1][0]} ${bottom} L ${forecastPoints[0][0]} ${bottom} Z`;
  const actualCircles = actualPoints.map(([x, y], index) => `<circle cx="${x}" cy="${y}" r="4"><title>${days[index].date.toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric' })}: ${values[index].toLocaleString('en', { maximumFractionDigits: 2 })} kg disposed</title></circle>`).join('');
  const forecastCircles = forecastPoints.slice(1).map(([x, y], index) => {
    const date = new Date(endDate);
    date.setDate(date.getDate() + index + 1);
    return `<circle cx="${x}" cy="${y}" r="4"><title>${date.toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric' })}: predicted ${forecast[index].toLocaleString('en', { maximumFractionDigits: 2 })} kg</title></circle>`;
  }).join('');

  yAxis.innerHTML = Array.from({ length: 5 }, (_, index) => `<span>${(maximum - (index * maximum / 4)).toLocaleString('en', { maximumFractionDigits: 1 })}</span>`).join('');
  xAxis.innerHTML = [
    ...days.map((day) => day.date.toLocaleDateString('en', { weekday: 'short' })),
    ...forecast.map((_, index) => {
      const date = new Date(endDate);
      date.setDate(date.getDate() + index + 1);
      return date.toLocaleDateString('en', { weekday: 'short' });
    }),
  ].map((label) => `<span>${label}</span>`).join('');
  chart.setAttribute('aria-label', `Actual ingredient disposal in kilograms${hasEnoughDays ? ' and two-day forecast' : ''}`);
  chart.innerHTML = `<path class="actual-area" d="${actualArea}"></path><path class="actual-line" d="${actualLine}"></path><g class="actual-points">${actualCircles}</g>${forecast.length ? `<path class="predicted-area" d="${forecastArea}"></path><path class="predicted-line" d="${forecastLine}"></path><g class="predicted-points">${forecastCircles}</g>` : ''}`;
  const total = values.reduce((sum, value) => sum + value, 0);
  return { total, average: total / values.length, rSquared };
}

async function renderDashboard() {
  if (!document.querySelector('.metric-grid')) return;
  try {
    const [ingredients, disposalRecords] = await Promise.all([
      requestAPI('/ingredients'),
      requestAPI('/disposals'),
    ]);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const firstDay = new Date(today);
    firstDay.setDate(firstDay.getDate() - 6);
    const startKey = getDashboardDateKey(firstDay);
    const tomorrowKey = getDashboardDateKey(tomorrow);
    const weekRecords = disposalRecords.filter((record) => {
      const date = new Date(record.disposed_at);
      if (Number.isNaN(date.getTime())) return false;
      const key = getDashboardDateKey(date);
      return key >= startKey && key < tomorrowKey;
    });
    const todayKey = getDashboardDateKey(today);
    const todayRecords = weekRecords.filter((record) => getDashboardDateKey(new Date(record.disposed_at)) === todayKey);
    const outOfStock = ingredients.filter((ingredient) => Number(ingredient.quantity) <= 0);
    const expiring = ingredients.map((ingredient) => ({
      ...ingredient,
      expiresAt: ingredient.expires_at ? new Date(ingredient.expires_at) : null,
    })).filter((ingredient) => (
      Number(ingredient.quantity) > 0 && ingredient.expiresAt
      && !Number.isNaN(ingredient.expiresAt.getTime())
      && ingredient.expiresAt <= new Date(now.getTime() + 86400000)
    ));
    const stockedCount = ingredients.filter((ingredient) => Number(ingredient.quantity) > 0).length;
    const stockPercent = ingredients.length ? Math.round((stockedCount / ingredients.length) * 100) : 0;

    document.querySelector('#dashboard-weekly-disposals').textContent = weekRecords.length;
    document.querySelector('#dashboard-weekly-caption').innerHTML = `<i class="bi bi-database"></i> ${todayRecords.length} today`;
    document.querySelector('#dashboard-ingredient-count').textContent = ingredients.length;
    document.querySelector('#dashboard-stock-caption').textContent = 'Inventory records';
    document.querySelector('#dashboard-out-of-stock').textContent = outOfStock.length;
    document.querySelector('#dashboard-out-of-stock-caption').textContent = outOfStock.length ? 'Need replenishment' : 'All tracked items stocked';
    document.querySelector('#dashboard-expiring-count').textContent = expiring.length;
    document.querySelector('#dashboard-expiring-caption').textContent = expiring.length ? 'Within 24 hours or expired' : 'No upcoming expiry alerts';
    renderDashboardDisposalChart(weekRecords, firstDay, today);

    const typeCounts = new Map();
    weekRecords.forEach((record) => {
      const type = record.item_type === 'ingredient' ? 'Ingredients' : 'Prepared food';
      typeCounts.set(type, (typeCounts.get(type) || 0) + 1);
    });
    const totalRecords = weekRecords.length;
    const ingredientPercent = totalRecords ? Math.round(((typeCounts.get('Ingredients') || 0) / totalRecords) * 100) : 0;
    const donut = document.querySelector('#dashboard-type-donut');
    donut.style.background = totalRecords
      ? `conic-gradient(#f59b1d 0 ${ingredientPercent}%, #3bb366 ${ingredientPercent}% 100%)`
      : 'conic-gradient(#e9eff0 0 100%)';
    document.querySelector('#dashboard-type-total').textContent = totalRecords;
    const categories = [
      { name: 'Ingredients', color: 'fried' },
      { name: 'Prepared food', color: 'drinks' },
    ].map((category) => ({ ...category, count: typeCounts.get(category.name) || 0 })).filter((category) => category.count);
    document.querySelector('#dashboard-type-list').innerHTML = categories.length
      ? categories.map((category) => `<li><b class="dot ${category.color}"></b><span>${category.name}<small>${category.count} records (${Math.round(category.count / totalRecords * 100)}%)</small></span></li>`).join('')
      : '<li>No disposal records in the last 7 days.</li>';

    const itemTotals = new Map();
    weekRecords.forEach((record) => {
      const unit = String(record.unit || '');
      const type = String(record.item_type || '');
      const name = String(record.item_name || '');
      const key = `${type}:${name.toLocaleLowerCase()}:${unit}`;
      const item = itemTotals.get(key) || { name, type, unit, quantity: 0, count: 0 };
      item.quantity += Number(record.quantity) || 0;
      item.count += 1;
      itemTotals.set(key, item);
    });
    const topItems = [...itemTotals.values()].sort((a, b) => b.count - a.count || b.quantity - a.quantity).slice(0, 3);
    document.querySelector('#dashboard-top-items').innerHTML = topItems.length
      ? topItems.map((item) => `<li><span><i class="bi ${item.type === 'food' ? 'bi-egg-fried' : 'bi-box-seam'}"></i></span><b>${escapeHTML(item.name)}<small>${item.count} disposal record${item.count === 1 ? '' : 's'}</small></b><strong>${item.quantity.toLocaleString('en', { maximumFractionDigits: 2 })} ${escapeHTML(item.unit)}</strong></li>`).join('')
      : '<li class="dashboard-empty">No disposal records in the last 7 days.</li>';

    document.querySelector('#dashboard-stock-ring').style.setProperty('--stock-progress', `${stockPercent}%`);
    document.querySelector('#dashboard-stock-percent').textContent = ingredients.length ? `${stockPercent}%` : '--';
    document.querySelector('#dashboard-stock-available').textContent = stockedCount;
    document.querySelector('#dashboard-stock-total').textContent = ingredients.length;
    document.querySelector('#dashboard-stock-summary').textContent = `${outOfStock.length} out of stock`;
    document.querySelector('#dashboard-stock-tip').textContent = outOfStock.length ? `${outOfStock.length} ingredients need replenishment.` : 'All tracked ingredients currently have stock.';

    const alerts = [
      ...expiring.map((ingredient) => ({
        icon: 'bi-hourglass-split',
        type: 'warning',
        title: `${ingredient.name} ${ingredient.expiresAt <= now ? 'is expired' : 'expires within 24 hours'}`,
        detail: `${Number(ingredient.quantity).toLocaleString('en', { maximumFractionDigits: 2 })} ${inventoryIngredientUnits.get(ingredient.name.trim().toLocaleLowerCase()) || 'kg'} on hand`,
      })),
      ...outOfStock.map((ingredient) => ({ icon: 'bi-box-seam', type: 'info', title: `${ingredient.name} is out of stock`, detail: 'Replenish this inventory item.' })),
    ].slice(0, 4);
    document.querySelector('#dashboard-alerts').innerHTML = alerts.length
      ? alerts.map((alert) => `<div class="alert-item"><span class="alert-icon ${alert.type}"><i class="bi ${alert.icon}"></i></span><p><b>${escapeHTML(alert.title)}</b><small>${escapeHTML(alert.detail)}</small></p></div>`).join('')
      : '<p class="dashboard-empty">No current inventory alerts.</p>';
  } catch (error) {
    ['dashboard-weekly-disposals', 'dashboard-ingredient-count', 'dashboard-out-of-stock', 'dashboard-expiring-count', 'dashboard-type-total', 'dashboard-stock-percent'].forEach((id) => {
      const element = document.querySelector(`#${id}`);
      if (element) element.textContent = '--';
    });
    document.querySelector('#dashboard-type-list').innerHTML = `<li class="dashboard-empty">${escapeHTML(error.message)}</li>`;
    document.querySelector('#dashboard-top-items').innerHTML = `<li class="dashboard-empty">${escapeHTML(error.message)}</li>`;
    document.querySelector('#dashboard-alerts').innerHTML = `<p class="dashboard-empty">${escapeHTML(error.message)}</p>`;
  }
}

renderDashboard();
